#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"


void
on_shok2_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_shok1_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_shAfficher_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_shModifier_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_shAjouter_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_shchoisir_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_shretour_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_shSupprimer_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}

