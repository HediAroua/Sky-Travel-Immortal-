#include <gtk/gtk.h>



void
on_shAfficher_clicked                  (GtkWidget       *shobjet,
                                        gpointer         user_data);

void
on_shok2_clicked                       (GtkWidget       *shobjet,
                                        gpointer         user_data);

void
on_shok1_clicked                       (GtkWidget       *shobjet,
                                        gpointer         user_data);


void
on_shSupprimer_clicked                 (GtkWidget       *shobjet,
                                        gpointer         user_data);

void
on_shchoisir_clicked                   (GtkWidget       *shobjet,
                                        gpointer         user_data);

void
on_shretour_clicked                    (GtkWidget       *shobjet,
                                        gpointer         user_data);

void
on_shModifier_clicked                  (GtkWidget       *shobjet,
                                        gpointer         user_data);
void
on_shAjouter_clicked                   (GtkWidget      *shobjet,
                                        gpointer         user_data);

