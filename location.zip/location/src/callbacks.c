#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"ajouter.h"
#include <string.h>


void
on_buttonsupprimertg_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char marque[2000];
GtkWidget *recherche ;

recherche=lookup_widget(objet_graphique,"entryrecherchetg");


strcpy(marque,gtk_entry_get_text(GTK_ENTRY(recherche)));

supprimerlocation(marque);
}


void
on_buttonmodifertg_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char marque[2000];
GtkWidget *emp ,*modif ,*recherche;

recherche=lookup_widget(objet_graphique,"entryrecherchetg");

emp=lookup_widget(objet_graphique,"locationEmptg");
modif=create_Modifierlocationtg();
gtk_widget_show(modif);
gtk_widget_hide(emp);

strcpy(marque,gtk_entry_get_text(GTK_ENTRY(recherche)));
}


void
on_buttonajoutertg_clicked             (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *emp ,*ajout ;

emp=lookup_widget(objet_graphique,"locationEmptg");
ajout=create_ajouterloctg();
gtk_widget_show(ajout);
gtk_widget_hide(emp);
}


void
on_buttonaffichagetg_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *emploc,*treeview;

emploc=lookup_widget(objet_graphique,"locationEmptg");



treeview=lookup_widget(emploc,"treeviewloctg");
afficherlocation(treeview) ; 
}


void
on_buttonvaliderloctg_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE *f ; 
loc l ; 
GtkWidget *inputmarque , *inputprix ;
GtkWidget *emp ,*ajout ;

ajout=lookup_widget(objet_graphique,"ajouterloctg");
emp=create_locationEmptg();
gtk_widget_show(emp);
gtk_widget_hide(ajout); 

inputmarque=lookup_widget(objet_graphique,"entrymarquetg"); 
inputprix=lookup_widget(objet_graphique,"entryprixtg"); 

strcpy(l.marque,gtk_entry_get_text(GTK_ENTRY(inputmarque)));
strcpy(l.prix,gtk_entry_get_text(GTK_ENTRY(inputprix)));
ajouterlocation(l) ; 
}


void
on_buttonvaliderprixtg_clicked         (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
char nouveau[50];
char marque[2000];
GtkWidget *nprix,*ancienmarque;
GtkWidget *emp ,*modif ;

modif=lookup_widget(objet_graphique,"Modifierlocationtg");
emp=create_locationEmptg();
gtk_widget_show(emp);
gtk_widget_hide(modif);
nprix=lookup_widget(objet_graphique,"entrynouveauprixtg");
ancienmarque=lookup_widget(objet_graphique,"TKentry1");

strcpy(nouveau,gtk_entry_get_text(GTK_ENTRY(nprix)));
strcpy(marque,gtk_entry_get_text(GTK_ENTRY(ancienmarque)));
modifierlocation(marque,nouveau);
}


