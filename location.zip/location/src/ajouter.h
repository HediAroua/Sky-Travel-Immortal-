#include <gtk/gtk.h>

typedef struct 
{
char marque[50] ;
char prix[50];  
}loc ; 

 


void ajouterlocation (loc l) ;
void afficherlocation(GtkTreeView *liste) ; 
int verifierdest (char marque[][50]) ;
void supprimerlocation(char marque[]) ; 
void modifierlocation(char marque[] ,char newprix[]);
