#include <gtk/gtk.h>



void
on_buttonsupprimertg_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonmodifertg_clicked             (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_buttonajoutertg_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonaffichagetg_clicked           (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_buttonvaliderloctg_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonvaliderprixtg_clicked         (GtkWidget      *objet_graphique,
                                        gpointer         user_data);


