#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "personne.h"
#include <gtk/gtk.h>

enum{
      
         NOM,
         PRENOM,
         NAISSANCE,
         SEXE,
         MAIL,
         COLUMNS
};

void ajouter_personne(Personne p){

int r=2;
FILE *f7=fopen("log.txt","a+");
FILE *f=fopen("employée.txt","a+");
if(f!=NULL && f7!=NULL)
{
fprintf(f,"%s %s %d/%d/%d %s %s \n",p.nom,p.prenom,p.dt.jour,p.dt.mois,p.dt.annee,p.sexe,p.mail);
fprintf(f7,"%s %d %d \n",p.mail,p.dt.annee,r);

fclose(f);
fclose(f7);
}
}
void afficher_personne(GtkWidget *liste){
        GtkCellRenderer *renderer;
        GtkTreeViewColumn *column;
        GtkTreeIter  iter;
        GtkListStore *store;

        char nom[30];
        char prenom[30];
        char naissance[30];
        char sexe[30];
        char mail[30];
        store=NULL;

         FILE *f;
         store=gtk_tree_view_get_model(liste);
         if(store==NULL){

renderer=gtk_cell_renderer_text_new();      
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();      
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();       
column=gtk_tree_view_column_new_with_attributes("naissance",renderer,"text",NAISSANCE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

     
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",SEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();       
column=gtk_tree_view_column_new_with_attributes("mail",renderer,"text",MAIL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);}
f=fopen("employée.txt","r");
if(f==NULL){
    return;
}
else
f=fopen("employée.txt","a+");
while(fscanf(f,"%s %s %s %s %s \n",nom,prenom,naissance,sexe,mail)!=EOF){
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM,nom,PRENOM,prenom,NAISSANCE,naissance,SEXE,sexe,MAIL,mail,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}

void supprimer_personne(char mail[]){
FILE *f_h;
FILE *f_h1;
Personne p; 
char naissance[30]; 
int r;
int n;
f_h=fopen("employée.txt","r");
f_h1=fopen("employée1.txt","w");
if (f_h!=NULL){
    if(f_h1!=NULL){
while(fscanf(f_h,"%s %s %s %s %s\n",p.nom,p.prenom,naissance,p.sexe,p.mail)!=EOF ) {
    if(strcmp(mail,p.mail)!=0){
        fprintf(f_h1,"%s %s %s %s %s\n",p.nom,p.prenom,naissance,p.sexe,p.mail);
        r=1;
    }
}
    }
    fclose(f_h1);
}

fclose(f_h);
if (r){
	remove ("employée.txt");
	rename ("employée1.txt","employée.txt");
	}
}

void modifier_personne(char mail[],NewPersonne p1){
int n=0;
Personne p ;

char naissance[30];


FILE *f_h;
FILE *f_h1;
 


f_h=fopen("employée.txt","r");
f_h1=fopen("employée1.txt","w");
if (f_h!=NULL)
{
    if(f_h1!=NULL)
     {
while(fscanf(f_h,"%s %s %s %s %s\n",p.nom,p.prenom,naissance,p.sexe,p.mail)!=EOF )
{
    if(strcmp(mail,p.mail)==0)
            {
        fprintf(f_h1,"%s %s %s %s %s\n",p1.nom1,p1.prenom1,p1.naissance1,p1.sexe1,p1.mail1);
            }
     else 
          {fprintf(f_h1,"%s %s %s %s %s\n",p.nom,p.prenom,naissance,p.sexe,p.mail); 
}
}
}
fclose(f_h1);
fclose(f_h);

	remove ("employée.txt");
	rename ("employée1.txt","employée.txt");
	}
}
