#include <gtk/gtk.h>



void HARafficher_vol(GtkWidget *liste);
int HARajouter_vol(char cin[100]);
