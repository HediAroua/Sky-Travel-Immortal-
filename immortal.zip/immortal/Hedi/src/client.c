#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "client.h"
#include "HAreservation.h"

int ajouter_client(char user[],char nom[],char prenom[],char cin[], char email[],char naissance[] ,char password[],char occupation[],char civil[], int enfant)
{

char user1[50];
char nom1[50];
char prenom1[50];
char cin1[50];
char email1[50];
char naissance1[50];
char password1[50];
char occupation1[50];
char civil1[50];
int enfant1;

FILE *f, *f1;
int r=3; 
int x=0;
f=fopen("client.txt","a+");
f1=fopen("log.txt","a+");
if (f!=NULL && f1!=NULL)
	{
        while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d %d \n",user1,nom1,prenom1,cin1,email1,password1,naissance1,occupation1,civil1,&enfant1,&r)!=EOF)
       {
        if (strcmp(user,user1)==0) 
         {
          x=1;
		return x;
          }
        }
      if (x!=1)    
         {	
	fprintf(f,"%s %s %s %s %s %s %s %s %s %d %d\n",user,nom,prenom,cin,email,password,naissance,occupation,civil,enfant,r);
	fprintf(f1,"%s %s %d \n",user,password,r);
         }
         
         } 
	fclose(f);
	fclose(f1);
      
	
}

int authentification (char user[], char password[])
{
FILE *f, *f1 , *fc;
char user1[50];
char password1[50];
int role,r;
int i=0;


char nom1[50];
char prenom1[50];
char email1[50];
char naissance1[50];

char occupation1[50];
char civil1[50];
char cin1[50];
int enfant1;


char user0[50];
char password0[50];
char nom0[50];
char prenom0[50];
char cin0[50];
char email0[50];
char naissance0[50];
char occupation0[50];
char civil0[50];
int enfant0;



fc=fopen("client.txt","r");
f=fopen("log.txt","r");
f1=fopen("fiche_cnx.txt","w");
if(f !=NULL) {
while(fscanf(f,"%s %s %d \n",user1,password1,&role)!=EOF){ 
if (strcmp(user,user1)==0 && strcmp(password,password1)==0)
	{
	i=role; 
		
		while(fscanf(fc,"%s %s %s %s %s %s %s %s %s %d %d",user0,nom0,prenom0,cin0,email0,password0,naissance0,occupation0,civil0,&enfant0,&r)!=EOF)
		{
		if (strcmp(user1,user0)==0 )
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s %s %d %d",user0,nom0,prenom0,cin0,email0,password0,naissance0,occupation0,civil0,enfant0,r);
		}
		}
	}
}
}
fclose(f1);
fclose(f);
fclose(fc);
return i;

}


void modification_profil_client (char user[], char email[],char password[],char occupation[],char civil[], int enfant)
{
FILE *f;
FILE *f1;
FILE *f2;
FILE *f3;
FILE *f4;


char user1[50];
char nom1[50];
char cin1[50];
char prenom1[50];
char email1[50];
char naissance1[50];
char password1[50];
char occupation1[50];
char civil1[50];
int enfant1;
int r ;

f=fopen("client.txt","r");
f1=fopen("tmp.txt","w");
f2=fopen("fiche_cnx.txt","w");
f3=fopen("log.txt","r");
f4=fopen("tmplog.txt","w");
if(f!=NULL) 
{
	if (f1!=NULL)
	{
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d %d \n",user1,nom1,prenom1,cin1,email1,password1,naissance1,occupation1,civil1,&enfant1,&r)!=EOF){
	if (strcmp(user1,user)==0)
		{
	fprintf(f1,"%s %s %s %s %s %s %s %s %s %d %d \n",user1,nom1,prenom1,cin1,email,password,naissance1,occupation,civil,enfant,r);
	fprintf(f2,"%s %s %s %s %s %s %s %s %s %d %d \n",user1,nom1,prenom1,cin1,email,password,naissance1,occupation,civil,enfant,r);
		}
             else 
             {fprintf(f1,"%s %s %s %s %s %s %s %s %s %d %d \n",user1,nom1,prenom1,cin1,email1,password1,naissance1,occupation1,civil1,enfant1,r);
             } 

	}
}
fclose(f1);
fclose(f2);
}
fclose(f);

remove("client.txt");
rename("tmp.txt","client.txt");
////////////////////////////////////////////////////////////////////////////
if(f3!=NULL) 
{
	if (f4!=NULL)
	{
while(fscanf(f3,"%s %s %d \n",user1,password1,&r)!=EOF){
	if (strcmp(user1,user)==0)
		{
	fprintf(f4,"%s %s %d \n",user1,password,r);
		}
             else 
             {fprintf(f4,"%s %s %d \n",user1,password1,r);
             } 

	}
}
fclose(f4);
}
fclose(f3);

remove("log.txt");
rename("tmplog.txt","log.txt");


}

void supprimer_client (char user[])
{
char user1[50];
char password1[50];
char role1[50];
FILE *f;
FILE *f1;
f=fopen("log.txt","r");
f1=fopen("tmp.txt","w");
if(f!=NULL) 
 {
   if(f1!=NULL) 
    {
while(fscanf(f,"%s %s %s \n",user1,password1,role1)!=EOF)
{
if(strcmp(user1,user)!=0)
   {
fprintf(f1,"%s %s %s \n",user1,password1,role1);
   }
}
}
fclose(f1);
}
fclose(f);

remove("log.txt");
rename("tmp.txt","log.txt");

}

enum
{
	NOM,
	PRENOM,
	CIN,
	DATERESR,
	DEPART,
	DESTINATION,
	DATEDEPART,
	DATERETOUR,
	COMPAGNIE,
	PRIX,
	NOMBRESIEGE,
	PRIXT,


	COLUMNS
};



void ANafficher_vol(GtkWidget *liste)
{

 GtkCellRenderer *renderer;
 GtkTreeViewColumn *column;
 GtkTreeIter iter;
 GtkListStore *store;

char Nom[100];
char Prenom[100];
char Cin[100];
char dateresr[100];
char depart[100];
char destination[100];
char datedepart[100];
char dateretour[100];
char compagnie[100];
char prix[100];
int nombre;
int prixt;


 store=NULL;

 FILE *f;

 store=gtk_tree_view_get_model(liste);
 if(store==NULL)
 {
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Nom", renderer, "text",NOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Prenom", renderer, "text", PRENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" CIN", renderer, "text", CIN, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date de reservation", renderer, "text",DATERESR, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Depart", renderer, "text",DEPART, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Destination", renderer, "text",DESTINATION, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date de depart", renderer, "text",DATEDEPART, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date de retour", renderer, "text",DATERETOUR, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Compagnie", renderer, "text",COMPAGNIE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Prix unitaire", renderer, "text",PRIX, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Nombre de siege", renderer, "text",NOMBRESIEGE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Prix totale", renderer, "text",PRIXT, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);



 store= gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT,G_TYPE_INT);

 f= fopen("tmpArbi.txt","r");

 if(f==NULL)
 {
	return;
 }

 else

 { f = fopen("tmpArbi.txt","a+");
	while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %d %d\n", Nom,Prenom,Cin,dateresr,depart,destination,datedepart,dateretour,compagnie,prix,&nombre,&prixt)!=EOF)
	{
          gtk_list_store_append (store,&iter);
          gtk_list_store_set (store, &iter, NOM, Nom, PRENOM, Prenom, CIN, Cin, DATERESR, dateresr,DEPART,depart, DESTINATION, destination ,DATEDEPART,datedepart, DATERETOUR,dateretour,COMPAGNIE,compagnie,PRIX,prix,NOMBRESIEGE,nombre,PRIXT,prixt, -1);
	}
  fclose(f);
  gtk_tree_view_set_model(GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
  g_object_unref (store);
 }

}
}

int ANhistorique_vol ()
{

char user1[50];
char nom1[50];
char prenom1[50];
char cin1[50];
char email1[50];
char naissance1[50];
char password1[50];
char occupation1[50];
char civil1[50];
int enfant1;
int r;


int s=1;
FILE *f,*f1, *f2;
    HAvol v;
    f=fopen("res.txt","r");
    f1=fopen("client.txt","r");
    f2=fopen("tmpArbi.txt","w");

  if ((f!=NULL) && (f1!=NULL) && (f2!=NULL))
	
{
  
  while
        ( (fscanf (f,"%s %s %s %d/%d/%d %s %s %s %s %s %s %d %d\n", v.HANom,v.HAPrenom,v.HACin,&v.HAdateresr.HAjour,&v.HAdateresr.HAmois,&v.HAdateresr.HAannee,v.HAdepart,v.HAdestination,v.HAdatedepart,v.HAdateretour,v.HAcompagnie,v.HAprix,&v.HAnombre,&v.HAprixt)!=EOF) && (fscanf(f1,"%s %s %s %s %s %s %s %s %s %d %d \n",user1,nom1,prenom1,cin1,email1,password1,naissance1,occupation1,civil1,&enfant1,&r)!=EOF) )
	{

            if(strcmp(cin1,v.HACin)!=0)
		{
fprintf(f2,"%s %s %s %d/%d/%d %s %s %s %s %s %s %d %d\n", v.HANom,v.HAPrenom,v.HACin,v.HAdateresr.HAjour,v.HAdateresr.HAmois,v.HAdateresr.HAannee,v.HAdepart,v.HAdestination,v.HAdatedepart,v.HAdateretour,v.HAcompagnie,v.HAprix,v.HAnombre,v.HAprixt);
return s;
} 
        }
}


        fclose(f2);
        fclose(f1);
        fclose(f);

}

