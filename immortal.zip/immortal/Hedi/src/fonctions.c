#include <stdio.h>
#include <string.h>
#include "fonctions.h"
#include <gtk/gtk.h>


enum
{
	TYPE,
	DATE,
	ID,
	AVIS,
	COLUMNS
};

void ajouter_reclamation(reclamation p)
{

 FILE *f;
 f=fopen("reclamation.txt","a+");
 if(f!=NULL)
 {
 fprintf(f,"%s %s %s %s \n",p.yk_type,p.yk_date,p.yk_id,p.yk_avis);
 fclose(f);
 }

}


void afficher_reclamation(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char yk_type[20];
char yk_date[20];
char yk_id[20];
char yk_avis[100];

store =NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer=gtk_cell_renderer_text_new();	
	column=gtk_tree_view_column_new_with_attributes("yk_type",renderer,"text",TYPE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("yk_date",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("yk_id",renderer,"text",ID,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("yk_avis",renderer,"text",AVIS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f=fopen("reclamation.txt","r");

	if(f==NULL)
	{
		return;
	}
	else
	
	{ 
	f=fopen("reclamation.txt","a+");
		while(fscanf(f,"%s %s %s %s \n",yk_type,yk_date,yk_id,yk_avis)!=EOF)
		{
			gtk_list_store_append(store,&iter);
			      gtk_list_store_set(store,&iter,TYPE,yk_type,DATE,yk_date,ID,yk_id,AVIS,yk_avis,-1);
		}
	   fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
}
}

void supprimer_reclamation(char yk_id1[20])
{
FILE *f;
FILE *f1;
reclamation p;
f=fopen("reclamation.txt","r");
f1=fopen("set.txt","a+");
while (fscanf(f,"%s %s %s %s \n",p.yk_type,p.yk_date,p.yk_id,p.yk_avis)!=EOF)
{
	if(strcmp(p.yk_id,yk_id1)!=0)
	fprintf(f1,"%s %s %s %s \n",p.yk_type,p.yk_date,p.yk_id,p.yk_avis);
}
fclose(f);
fclose(f1);
remove("reclamation.txt");
rename("set.txt","reclamation.txt");
}


















