#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <gtk/gtkclist.h>
#include <gdk/gdkkeysyms.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "HAreservation.h"
#include "HAreservationvoiture.h"
#include "HArechvoiture.h"
#include "client.h"
#include "fonctions.h"
#include "personne.h"
#include "shfonctions.h"
#include "ajouter.h"


/***********************************************************************************/


/******************** Debut TRAVAIL DE HEDI AROUA **********************************/


/********************************************************************************/

int global=0;


void on_HAbuttonAfficher_clicked    (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAFenetreReservation;
GtkWidget *HAFenetreAffichage;
GtkWidget *HAtreeview;

HAFenetreReservation=lookup_widget(objet,"HAFenetreReservation");

gtk_widget_destroy(HAFenetreReservation);
HAFenetreAffichage=lookup_widget(objet,"HAFenetreAffichage");
HAFenetreAffichage=create_HAFenetreAffichage();

gtk_widget_show(HAFenetreAffichage);

HAtreeview=lookup_widget(HAFenetreAffichage,"HAtreeview");

HAafficher_vol(HAtreeview);
}


/*******************************************************************/ 




void on_HAbuttonAjout_clicked     (GtkWidget       *objet, gpointer         user_data)
{


GtkWidget *input1, *input2, *input3,*output;
GtkWidget *HAFenetreReservation;

GtkWidget *HAspinbuttonJour;
GtkWidget *HAspinbuttonMois;
GtkWidget *HAspinbuttonAnnee;
GtkWidget *HAspinbuttonNbreSiege;

GtkWidget *HAcomboboxDepart;
GtkWidget *HAcomboboxDestination;
GtkWidget *HAcomboboxDatedepart;
GtkWidget *HAcomboboxDatearrive;
GtkWidget *HAcomboboxCompagnie;
GtkWidget *HAcomboboxPrix;

HAvol v;
int x;


HAFenetreReservation=lookup_widget(objet,"HAFenetreReservation");

input1=lookup_widget(objet,"HAentryNom");
input2=lookup_widget(objet,"HAentryPrenom");
input3=lookup_widget(objet,"HAentryCin");


strcpy(v.HANom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(v.HAPrenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(v.HACin,gtk_entry_get_text(GTK_ENTRY(input3)));

	HAspinbuttonJour=lookup_widget(objet, "HAspinbuttonJour");
	HAspinbuttonMois=lookup_widget(objet, "HAspinbuttonMois");
	HAspinbuttonAnnee=lookup_widget(objet, "HAspinbuttonAnnee");
	HAspinbuttonNbreSiege=lookup_widget(objet, "HAspinbuttonNbreSiege");

	HAcomboboxDepart=lookup_widget(objet, "HAcomboboxDepart");
	HAcomboboxDestination=lookup_widget(objet, "HAcomboboxDestination");
	HAcomboboxDatedepart=lookup_widget(objet, "HAcomboboxDatedepart");
	HAcomboboxDatearrive=lookup_widget(objet, "HAcomboboxDatearrive");
	HAcomboboxCompagnie=lookup_widget(objet, "HAcomboboxCompagnie");
	HAcomboboxPrix=lookup_widget(objet, "HAcomboboxPrix");

	v.HAdateresr.HAjour= gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(HAspinbuttonJour));
	v.HAdateresr.HAmois= gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(HAspinbuttonMois));
	v.HAdateresr.HAannee= gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(HAspinbuttonAnnee));
	v.HAnombre= gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(HAspinbuttonNbreSiege));

	if (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxDepart))!=-1)
	{ strcpy(v.HAdepart,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxDepart)));}

	if (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxDestination))!=-1)
	{ strcpy(v.HAdestination,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxDestination)));}

	if (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxDatedepart))!=-1)
	{ strcpy(v.HAdatedepart,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxDatedepart)));}

	if (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxDatearrive))!=-1)
	{ strcpy(v.HAdateretour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxDatearrive)));}

	if (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxCompagnie))!=-1)
	{ strcpy(v.HAcompagnie,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxCompagnie)));}

	if (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxPrix))!=-1)
	{ strcpy(v.HAprix,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxPrix)));}

v.HAprixt=HAcalculprix(v);
output=lookup_widget(objet,"HAlabelcontroleres");

if ( (strlen(v.HANom)==0) || (strlen(v.HAPrenom)==0) || (strlen(v.HACin)==0) )  
{
gtk_label_set_text(GTK_LABEL(output),"Verifier les champs vides !!");
}

else
{
x=HAajouter_vol(v);
if (x==1)
{
gtk_label_set_text(GTK_LABEL(output),"Votre reservation a ete enregistre avec succes !!");
}
else if (x!=1)
{
gtk_label_set_text(GTK_LABEL(output),"Nombre de siege indisponible !! ");
}
}
}



/*******************************************************************/ 



void on_HAbuttonModifier_clicked     (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAFenetreAffichage;
GtkWidget *HAFenetreModification;


HAFenetreAffichage=lookup_widget(objet,"HAFenetreAffichage");
gtk_widget_destroy(HAFenetreAffichage);

HAFenetreModification=lookup_widget(objet,"HAFenetreModification");
HAFenetreModification=create_HAFenetreModification();

gtk_widget_show(HAFenetreModification);
}


/*******************************************************************/ 




void on_HAbuttonSupprimer_clicked     (GtkWidget       *objet, gpointer         selection)
{
GtkWidget *HAFenetreAffichage;
GtkWidget *HAtreeview;
HAFenetreAffichage=lookup_widget(objet,"HAFenetreAffichage");
HAtreeview=lookup_widget(HAFenetreAffichage,"HAtreeview");
HAsupprimervol(HAtreeview);

}



/*******************************************************************/ 



void on_HAbuttonRetour_clicked     (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAFenetreAffichage;
GtkWidget *HAFenetreReservation;


HAFenetreAffichage=lookup_widget(objet,"HAFenetreAffichage");
gtk_widget_destroy(HAFenetreAffichage);

HAFenetreReservation=lookup_widget(objet,"HAFenetreReservation");
HAFenetreReservation=create_HAFenetreReservation();

gtk_widget_show(HAFenetreReservation);
}


/*******************************************************************/ 




void on_HAbuttonRemplir_clicked     (GtkWidget       *objet, gpointer         user_data)
{

GtkWidget *HAcomboboxDepart;
char depart[50][50];
int x,i;

HAcomboboxDepart=lookup_widget(objet, "HAcomboboxDepart");

x=HAFillDepart(depart);
for(i=0;i<=x;i++)
gtk_combo_box_remove_text (GTK_COMBO_BOX (HAcomboboxDepart),0);
for(i=0;i<x;i++)
{ gtk_combo_box_append_text (GTK_COMBO_BOX (HAcomboboxDepart),_(depart[i]));}
}

/*********************************************************************/


void on_HAbuttonConfirmerp_clicked     (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAcomboboxDepart;
GtkWidget *HAcomboboxDestination;
GtkWidget *output;
char destination[100][100];
char depart[100];
int i,y;
output=lookup_widget(objet,"HAlabelcontroleres");
	HAcomboboxDepart=lookup_widget(objet, "HAcomboboxDepart");
	HAcomboboxDestination=lookup_widget(objet, "HAcomboboxDestination");
	if (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxDepart))!=-1)
	{
strcpy(depart,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxDepart)));
y=HAFillDestination(destination,depart);
for(i=0;i<=y;i++)
gtk_combo_box_remove_text (GTK_COMBO_BOX (HAcomboboxDestination),0);
for(i=0;i<y;i++)
gtk_combo_box_append_text (GTK_COMBO_BOX (HAcomboboxDestination),_(destination[i]));
	}
else 
{
gtk_label_set_text(GTK_LABEL(output),"Verifier les champs vides !!");
}

}

/************************************************************************/


void on_HAbuttonConfirmerd_clicked     (GtkWidget       *objet, gpointer         user_data)
{
HAvol v;
GtkWidget *HAcomboboxDepart;
GtkWidget *HAcomboboxDestination;
GtkWidget *HAcomboboxDatedepart;
GtkWidget *HAcomboboxDatearrive;
GtkWidget *HAcomboboxCompagnie;
GtkWidget *HAcomboboxPrix;
GtkWidget *output;


char datedepart[100][100];
char datearrive[100][100];
char compagnie[100][100];
char PRIX[100][100];
char depart[100];
char destination[100];
int i,d,r,c,p;
	output=lookup_widget(objet,"HAlabelcontroleres");
	HAcomboboxDepart=lookup_widget(objet, "HAcomboboxDepart");
	HAcomboboxDestination=lookup_widget(objet, "HAcomboboxDestination");
	HAcomboboxDatedepart=lookup_widget(objet, "HAcomboboxDatedepart");
	HAcomboboxDatearrive=lookup_widget(objet, "HAcomboboxDatearrive");
	HAcomboboxCompagnie=lookup_widget(objet, "HAcomboboxCompagnie");
	HAcomboboxPrix=lookup_widget(objet, "HAcomboboxPrix");
	

	if ( (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxDestination))!=-1) &&  (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxDepart))!=-1) )
	{
strcpy(depart,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxDepart)));
strcpy(destination,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxDestination)));

d=HAFillDatedepart(datedepart,destination,depart);
r=HAFillDatearrive(datearrive,destination,depart);
c=HAFillCompagnie(compagnie,destination,depart);
p=HAFillPrix(PRIX,destination,depart);

for(i=0;i<=d;i++)
gtk_combo_box_remove_text (GTK_COMBO_BOX (HAcomboboxDatedepart),0);
for(i=0;i<d;i++)
gtk_combo_box_append_text (GTK_COMBO_BOX (HAcomboboxDatedepart),_(datedepart[i]));

for(i=0;i<=r;i++)
gtk_combo_box_remove_text (GTK_COMBO_BOX (HAcomboboxDatearrive),0);
for(i=0;i<r;i++)
gtk_combo_box_append_text (GTK_COMBO_BOX (HAcomboboxDatearrive),_(datearrive[i]));

for(i=0;i<=c;i++)
gtk_combo_box_remove_text (GTK_COMBO_BOX (HAcomboboxCompagnie),0);
for(i=0;i<c;i++)
gtk_combo_box_append_text (GTK_COMBO_BOX (HAcomboboxCompagnie),_(compagnie[i]));

for(i=0;i<=p;i++)
gtk_combo_box_remove_text (GTK_COMBO_BOX (HAcomboboxPrix),0);
for(i=0;i<p;i++)
gtk_combo_box_append_text (GTK_COMBO_BOX (HAcomboboxPrix),_(PRIX[i]));
	}

else 
{
gtk_label_set_text(GTK_LABEL(output),"Verifier les champs vides !!");
}

}

/****************************************************************************/




void on_HAbuttonOK3_clicked     (GtkWidget       *objet, gpointer         user_data)
{


char depart[50][50];
GtkWidget *HAcomboboxDepart3;

int x,i;

HAcomboboxDepart3=lookup_widget(objet, "HAcomboboxDepart3");

x=HAFillDepart(depart);
for(i=0;i<=x;i++)
gtk_combo_box_remove_text (GTK_COMBO_BOX (HAcomboboxDepart3),0);
for(i=0;i<x;i++)
{ gtk_combo_box_append_text (GTK_COMBO_BOX (HAcomboboxDepart3),_(depart[i]));}
}


/**************************************************************/



void on_HAbuttonConfirmerDepart3_clicked     (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAcomboboxDepart3;
GtkWidget *HAcomboboxDestination3;
GtkWidget *output;
char destination[100][100];
char depart[100];
int i,y;

	output=lookup_widget(objet,"HAlabelmod80");
	HAcomboboxDepart3=lookup_widget(objet, "HAcomboboxDepart3");
	HAcomboboxDestination3=lookup_widget(objet, "HAcomboboxDestination3");
	if (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxDepart3))!=-1)
	{
strcpy(depart,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxDepart3)));
y=HAFillDestination(destination,depart);
for(i=0;i<=y;i++)
gtk_combo_box_remove_text (GTK_COMBO_BOX (HAcomboboxDestination3),0);
for(i=0;i<y;i++)
gtk_combo_box_append_text (GTK_COMBO_BOX (HAcomboboxDestination3),_(destination[i]));
	}

else 
{
gtk_label_set_text(GTK_LABEL(output),"Verifier les champs vides !!");
}

}

/**************************************************************/


void on_HAbuttonConfirmerDestination3_clicked     (GtkWidget       *objet, gpointer         user_data)
{
HAvol v;
GtkWidget *HAcomboboxDepart3;
GtkWidget *HAcomboboxDestination3;
GtkWidget *HAcomboboxDatedepart3;
GtkWidget *HAcomboboxDateretour3;
GtkWidget *HAcomboboxCompagnie3;
GtkWidget *HAcomboboxPrix3;
GtkWidget *output;


char datedepart[100][100];
char datearrive[100][100];
char compagnie[100][100];
char PRIX[100][100];
char depart[100];
char destination[100];
int i,d,r,c,p;

	output=lookup_widget(objet,"HAlabelmod80");

	HAcomboboxDepart3=lookup_widget(objet, "HAcomboboxDepart3");
	HAcomboboxDestination3=lookup_widget(objet, "HAcomboboxDestination3");
	HAcomboboxDatedepart3=lookup_widget(objet, "HAcomboboxDatedepart3");
	HAcomboboxDateretour3=lookup_widget(objet, "HAcomboboxDateretour3");
	HAcomboboxCompagnie3=lookup_widget(objet, "HAcomboboxCompagnie3");
	HAcomboboxPrix3=lookup_widget(objet, "HAcomboboxPrix3");
	

	if ( (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxDestination3))!=-1) &&  (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxDepart3))!=-1) )
	{
strcpy(depart,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxDepart3)));
strcpy(destination,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxDestination3)));

d=HAFillDatedepart(datedepart,destination,depart);
r=HAFillDatearrive(datearrive,destination,depart);
c=HAFillCompagnie(compagnie,destination,depart);
p=HAFillPrix(PRIX,destination,depart);

for(i=0;i<=d;i++)
gtk_combo_box_remove_text (GTK_COMBO_BOX (HAcomboboxDatedepart3),0);
for(i=0;i<d;i++)
gtk_combo_box_append_text (GTK_COMBO_BOX (HAcomboboxDatedepart3),_(datedepart[i]));

for(i=0;i<=r;i++)
gtk_combo_box_remove_text (GTK_COMBO_BOX (HAcomboboxDateretour3),0);
for(i=0;i<r;i++)
gtk_combo_box_append_text (GTK_COMBO_BOX (HAcomboboxDateretour3),_(datearrive[i]));

for(i=0;i<=c;i++)
gtk_combo_box_remove_text (GTK_COMBO_BOX (HAcomboboxCompagnie3),0);
for(i=0;i<c;i++)
gtk_combo_box_append_text (GTK_COMBO_BOX (HAcomboboxCompagnie3),_(compagnie[i]));

for(i=0;i<=p;i++)
gtk_combo_box_remove_text (GTK_COMBO_BOX (HAcomboboxPrix3),0);
for(i=0;i<p;i++)
gtk_combo_box_append_text (GTK_COMBO_BOX (HAcomboboxPrix3),_(PRIX[i]));
	}
else 
{
gtk_label_set_text(GTK_LABEL(output),"Verifier les champs vides !!");
}
}


/**************************************************************/



void on_HAbuttonApply3_clicked     (GtkWidget       *objet, gpointer         user_data)
{



GtkWidget *input1, *input2, *input3,*input6,*output;
GtkWidget *HAFenetreModification;



GtkWidget *HAspinbuttonJour3;
GtkWidget *HAspinbuttonMois3;
GtkWidget *HAspinbuttonAnnee3;
GtkWidget *HAspinbuttonNombre3;

GtkWidget *HAcomboboxDepart3;
GtkWidget *HAcomboboxDestination3;
GtkWidget *HAcomboboxDatedepart3;
GtkWidget *HAcomboboxDateretour3;
GtkWidget *HAcomboboxCompagnie3;
GtkWidget *HAcomboboxPrix3;
HAvol v;
char cin[20];
int x=0;


HAFenetreModification=lookup_widget(objet,"HAFenetreModification");

input1=lookup_widget(objet,"HAentryNom3");
input2=lookup_widget(objet,"HAentryPrenom3");
input3=lookup_widget(objet,"HAentryCin3");


strcpy(v.HANom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(v.HAPrenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(v.HACin,gtk_entry_get_text(GTK_ENTRY(input3)));

	HAspinbuttonJour3=lookup_widget(objet, "HAspinbuttonJour3");
	HAspinbuttonMois3=lookup_widget(objet, "HAspinbuttonMois3");
	HAspinbuttonAnnee3=lookup_widget(objet, "HAspinbuttonAnnee3");
	HAspinbuttonNombre3=lookup_widget(objet, "HAspinbuttonNombre3");

	HAcomboboxDepart3=lookup_widget(objet, "HAcomboboxDepart3");
	HAcomboboxDestination3=lookup_widget(objet, "HAcomboboxDestination3");
	HAcomboboxDatedepart3=lookup_widget(objet, "HAcomboboxDatedepart3");
	HAcomboboxDateretour3=lookup_widget(objet, "HAcomboboxDateretour3");
	HAcomboboxCompagnie3=lookup_widget(objet, "HAcomboboxCompagnie3");
	HAcomboboxPrix3=lookup_widget(objet, "HAcomboboxPrix3");

	v.HAdateresr.HAjour= gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(HAspinbuttonJour3));
	v.HAdateresr.HAmois= gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(HAspinbuttonMois3));
	v.HAdateresr.HAannee= gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(HAspinbuttonAnnee3));
	v.HAnombre= gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(HAspinbuttonNombre3));


	if (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxDepart3))!=-1)
	{ strcpy(v.HAdepart,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxDepart3)));}

	if (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxDestination3))!=-1)
	{ strcpy(v.HAdestination,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxDestination3)));}

	if (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxDatedepart3))!=-1)
	{ strcpy(v.HAdatedepart,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxDatedepart3)));}

	if (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxDateretour3))!=-1)
	{ strcpy(v.HAdateretour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxDateretour3)));}

	if (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxCompagnie3))!=-1)
	{ strcpy(v.HAcompagnie,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxCompagnie3)));}

	if (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxPrix3))!=-1)
	{ strcpy(v.HAprix,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxPrix3)));}


input6=lookup_widget(objet,"HAentryCin2");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input6)));

output=lookup_widget(objet,"HAlabelmod80");
v.HAprixt=HAcalculprix(v);

if ( (strlen(v.HANom)==0) || (strlen(v.HAPrenom)==0) || (strlen(v.HACin)==0) )  
{
gtk_label_set_text(GTK_LABEL(output),"Verifier les champs vides !!");
}



else 
	{
x= HAmodifiervol(cin, v);


if (x!=1)
{
gtk_label_set_text(GTK_LABEL(output),"Verifier votre numero de CIN/passport !!");
}
else if (x==1)
{


gtk_label_set_text(GTK_LABEL(output),"Modification a eu lieu avec succes!");

}
	}

}


/**************************************************************/



void on_HAbuttonRetour3_clicked     (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAFenetreAffichage;
GtkWidget *HAFenetreModification;
GtkWidget *HAtreeview;

HAFenetreModification=lookup_widget(objet,"HAFenetreModification");
gtk_widget_destroy(HAFenetreModification);

HAFenetreAffichage=lookup_widget(objet,"HAFenetreAffichage");
HAFenetreAffichage=create_HAFenetreAffichage();

gtk_widget_show(HAFenetreAffichage);
HAtreeview=lookup_widget(HAFenetreAffichage,"HAtreeview");

HAafficher_vol(HAtreeview);
}


void
on_HAbuttonReserverVol_clicked    (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAFenetreReservation;
GtkWidget *HAMenuAgent;
GtkWidget *HAtreeview;

HAMenuAgent=lookup_widget(objet,"HAMenuAgent");
gtk_widget_destroy(HAMenuAgent);

HAFenetreReservation=lookup_widget(objet,"HAFenetreReservation");
HAFenetreReservation=create_HAFenetreReservation();

gtk_widget_show(HAFenetreReservation);



}







void
on_HAbuttonReservervoiture_clicked (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAFenetreReservationvoiture;
GtkWidget *HAMenuAgent;
GtkWidget *HAtreeview;

HAMenuAgent=lookup_widget(objet,"HAMenuAgent");
gtk_widget_destroy(HAMenuAgent);

HAFenetreReservationvoiture=lookup_widget(objet,"HAFenetreReservationvoiture");
HAFenetreReservationvoiture=create_HAFenetreReservationvoiture();

gtk_widget_show(HAFenetreReservationvoiture);
}




/************************************************************/


void on_HAbuttonFenetreRech_clicked         (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAFenetreAffichage;
GtkWidget *HAFenetreRecherchevol;


HAFenetreAffichage=lookup_widget(objet,"HAFenetreAffichage");
gtk_widget_destroy(HAFenetreAffichage);

HAFenetreRecherchevol=lookup_widget(objet,"HAFenetreRecherchevol");
HAFenetreRecherchevol=create_HAFenetreRecherchevol();

gtk_widget_show(HAFenetreRecherchevol);
}

/***************************************************************/



void on_HAbuttonRechercheVol_clicked        (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *input1,*output;
GtkWidget *HAtreeviewRechercheVol;

int x;
char cin[100];


input1=lookup_widget(objet,"HAentryCinRecherchevol");

output=lookup_widget(objet,"HAlabelErreurVol");

strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input1)));

HAtreeviewRechercheVol=lookup_widget(objet,"HAtreeviewRechercheVol");

x=HARajouter_vol(cin);
if (x==1)
{
HARafficher_vol(HAtreeviewRechercheVol);
gtk_label_set_text(GTK_LABEL(output),"Reservation trouve !!");
}
else if (x!=1)
{
gtk_label_set_text(GTK_LABEL(output),"Aucune reservation trouve, Verifier le numero de votre CIN !! ");
}

}



/*************************************************************/

void on_HAbuttonRetourRechercheVol_clicked  (GtkWidget       *objet, gpointer         user_data)
{

GtkWidget *HAFenetreAffichage;
GtkWidget *HAFenetreRecherchevol;
GtkWidget *HAtreeview;

HAFenetreRecherchevol=lookup_widget(objet,"HAFenetreRecherchevol");
gtk_widget_destroy(HAFenetreRecherchevol);

HAFenetreAffichage=lookup_widget(objet,"HAFenetreAffichage");
HAFenetreAffichage=create_HAFenetreAffichage();
gtk_widget_show(HAFenetreAffichage);
HAtreeview=lookup_widget(HAFenetreAffichage,"HAtreeview");

HAafficher_vol(HAtreeview);

}

/******************************             Voiture           ********************************/


void
on_HAbuttonConfirmMarque_clicked       (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAcomboboxmarquevoiture;
GtkWidget *HAcomboboxprixvoiture;
GtkWidget *output;
char PRIX[100][100];
char Marque[100];
int i,y;
	output =lookup_widget(objet,"HAlabelerreurvoiture");
	HAcomboboxmarquevoiture=lookup_widget(objet, "HAcomboboxmarquevoiture");
	HAcomboboxprixvoiture=lookup_widget(objet, "HAcomboboxprixvoiture");
	if (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxmarquevoiture))!=-1)
{
strcpy(Marque,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxmarquevoiture)));
y=HAFillPrixvoiture(PRIX,Marque);
for(i=0;i<=y;i++)
gtk_combo_box_remove_text (GTK_COMBO_BOX (HAcomboboxprixvoiture),0);
for(i=0;i<y;i++)
gtk_combo_box_append_text (GTK_COMBO_BOX (HAcomboboxprixvoiture),_(PRIX[i]));

}
else 
{
gtk_label_set_text(GTK_LABEL(output),"Verifier les champs vides !!");
}
}

/*****************************************************************/


void
on_HAbuttonRemplirmarque_clicked       (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAcomboboxmarquevoiture;
char Marque[50][50];
int x,i;

HAcomboboxmarquevoiture=lookup_widget(objet, "HAcomboboxmarquevoiture");

x=HAFillmarque(Marque);
for(i=0;i<=x;i++)
gtk_combo_box_remove_text (GTK_COMBO_BOX (HAcomboboxmarquevoiture),0);
for(i=0;i<x;i++)
{ gtk_combo_box_append_text (GTK_COMBO_BOX (HAcomboboxmarquevoiture),_(Marque[i]));}

}


/*****************************************************************/

void
on_Habuttonajoutervoiture_clicked     (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *input1, *input2, *input3,*output;
GtkWidget *HAFenetreReservationvoiture;

GtkWidget *HAspinbuttonjvoiture;
GtkWidget *HAspinbuttonmvoiture;
GtkWidget *HAspinbuttonavoiture;
GtkWidget *HAspinbuttonNombredujour;

GtkWidget *HAcomboboxmarquevoiture;
GtkWidget *HAcomboboxprixvoiture;


HAvoiture v;


HAFenetreReservationvoiture=lookup_widget(objet,"HAFenetreReservationvoiture");

input1=lookup_widget(objet,"HAentrynomvoiture");
input2=lookup_widget(objet,"Haentryprenomvoiture");
input3=lookup_widget(objet,"HAentrycinvoiture");


strcpy(v.HANomv,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(v.HAPrenomv,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(v.HACinv,gtk_entry_get_text(GTK_ENTRY(input3)));

	HAspinbuttonjvoiture=lookup_widget(objet, "HAspinbuttonjvoiture");
	HAspinbuttonmvoiture=lookup_widget(objet, "HAspinbuttonmvoiture");
	HAspinbuttonavoiture=lookup_widget(objet, "HAspinbuttonavoiture");
	HAspinbuttonNombredujour=lookup_widget(objet, "HAspinbuttonNombredujour");

	HAcomboboxmarquevoiture=lookup_widget(objet, "HAcomboboxmarquevoiture");
	HAcomboboxprixvoiture=lookup_widget(objet, "HAcomboboxprixvoiture");


	v.HAdateresrv.HAjour= gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(HAspinbuttonjvoiture));
	v.HAdateresrv.HAmois= gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(HAspinbuttonmvoiture));
	v.HAdateresrv.HAannee= gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(HAspinbuttonavoiture));
	v.HAnombredujourv= gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(HAspinbuttonNombredujour));

	if (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxmarquevoiture))!=-1)
	{strcpy(v.HAmarquev,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxmarquevoiture)));}
	if (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxprixvoiture))!=-1)
	{strcpy(v.HAprixv,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxprixvoiture)));}


	v.HAprixtv=HAcalculprixv(v);

output =lookup_widget(objet,"HAlabelerreurvoiture");
if ( (strlen(v.HANomv)==0) || (strlen(v.HAPrenomv)==0) || (strlen(v.HACinv)==0) )  
{
gtk_label_set_text(GTK_LABEL(output),"Verifier les champs vides !!");
}
else 
{
HAajouter_voiture(v);
gtk_label_set_text(GTK_LABEL(output),"Votre reservation a ete enregistre avec succes !!");
}


}


/*****************************************************************/

void
on_HAbuttonAffichervoiture_clicked     (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAFenetreReservationvoiture;
GtkWidget *HAFenetreAffichagevoiture;
GtkWidget *HAtreeviewvoiture;

HAFenetreReservationvoiture=lookup_widget(objet,"HAFenetreReservationvoiture");

gtk_widget_destroy(HAFenetreReservationvoiture);
HAFenetreAffichagevoiture=lookup_widget(objet,"HAFenetreAffichagevoiture");
HAFenetreAffichagevoiture=create_HAFenetreAffichagevoiture();

gtk_widget_show(HAFenetreAffichagevoiture);

HAtreeviewvoiture=lookup_widget(HAFenetreAffichagevoiture,"HAtreeviewvoiture");

HAafficher_voiture(HAtreeviewvoiture);
}


/*****************************************************************/



void
on_HAbuttonmodifiervoiture_clicked    (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAFenetreAffichagevoiture;
GtkWidget *HAFenetreModificationVoiture;


HAFenetreAffichagevoiture=lookup_widget(objet,"HAFenetreAffichagevoiture");
gtk_widget_destroy(HAFenetreAffichagevoiture);

HAFenetreModificationVoiture=lookup_widget(objet,"HAFenetreModificationVoiture");
HAFenetreModificationVoiture=create_HAFenetreModificationVoiture();

gtk_widget_show(HAFenetreModificationVoiture);
}


/*****************************************************************/


void
on_HAbuttonSupprimervoiture_clicked    (GtkWidget       *objet, gpointer         selection)
{
GtkWidget *HAFenetreAffichagevoiture;
GtkWidget *HAtreeviewvoiture;
HAFenetreAffichagevoiture=lookup_widget(objet,"HAFenetreAffichagevoiture");
HAtreeviewvoiture=lookup_widget(HAFenetreAffichagevoiture,"HAtreeviewvoiture");
HAsupprimervoiture(HAtreeviewvoiture);
}


/*****************************************************************/


void
on_HAbuttonRecherchevoiture_clicked    (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAFenetreAffichagevoiture;
GtkWidget *HAFenetreRechercheVoiture;


HAFenetreAffichagevoiture=lookup_widget(objet,"HAFenetreAffichagevoiture");
gtk_widget_destroy(HAFenetreAffichagevoiture);

HAFenetreRechercheVoiture=lookup_widget(objet,"HAFenetreRechercheVoiture");
HAFenetreRechercheVoiture=create_HAFenetreRechercheVoiture();

gtk_widget_show(HAFenetreRechercheVoiture);
}


/*****************************************************************/



void
on_HAbuttonconfirmmodmarque_clicked    (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAcomboboxmodMarquevoiture;
GtkWidget *HAcomboboxmodPrixvoiture;
GtkWidget *output;	
char PRIX[100][100];
char Marque[100];
int i,y;

	output=lookup_widget(objet,"HAlabelerreurMod");
	HAcomboboxmodMarquevoiture=lookup_widget(objet, "HAcomboboxmodMarquevoiture");
	HAcomboboxmodPrixvoiture=lookup_widget(objet, "HAcomboboxmodPrixvoiture");
	if (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxmodMarquevoiture))!=-1)
{
strcpy(Marque,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxmodMarquevoiture)));
y=HAFillPrixvoiture(PRIX,Marque);
for(i=0;i<=y;i++)
gtk_combo_box_remove_text (GTK_COMBO_BOX (HAcomboboxmodPrixvoiture),0);
for(i=0;i<y;i++)
gtk_combo_box_append_text (GTK_COMBO_BOX (HAcomboboxmodPrixvoiture),_(PRIX[i]));
}
else 
{
gtk_label_set_text(GTK_LABEL(output),"Verifier les champs vides !!");
}

}

/*****************************************************************/



void
on_HAbuttonConfirmmodCin_clicked      (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAcomboboxmodMarquevoiture;

char Marque[50][50];
int x,i;


HAcomboboxmodMarquevoiture=lookup_widget(objet, "HAcomboboxmodMarquevoiture");

x=HAFillmarque(Marque);
for(i=0;i<=x;i++)
gtk_combo_box_remove_text (GTK_COMBO_BOX (HAcomboboxmodMarquevoiture),0);
for(i=0;i<x;i++)
{ gtk_combo_box_append_text (GTK_COMBO_BOX (HAcomboboxmodMarquevoiture),_(Marque[i]));}

}

/*****************************************************************/



void
on_HAbuttonApplymodvoiture_clicked     (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *input1, *input2, *input3,*input6,*output;
GtkWidget *HAFenetreModificationVoiture;

GtkWidget *HAspinbuttonmodjvoiture;
GtkWidget *HAspinbuttonmodmvoiture;
GtkWidget *HAspinbuttonmodavoiture;
GtkWidget *HAspinbuttonmodnombrevoiture;

GtkWidget *HAcomboboxmodMarquevoiture;
GtkWidget *HAcomboboxmodPrixvoiture;


HAvoiture v;
char cin[20];
int x=0;


HAFenetreModificationVoiture=lookup_widget(objet,"HAFenetreModificationVoiture");

input1=lookup_widget(objet,"HAentryNommodvoiture");
input2=lookup_widget(objet,"HAentryPrenommodvoiture");
input3=lookup_widget(objet,"HAentryCinmodvoiture1");


strcpy(v.HANomv,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(v.HAPrenomv,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(v.HACinv,gtk_entry_get_text(GTK_ENTRY(input3)));

	HAspinbuttonmodjvoiture=lookup_widget(objet, "HAspinbuttonmodjvoiture");
	HAspinbuttonmodmvoiture=lookup_widget(objet, "HAspinbuttonmodmvoiture");
	HAspinbuttonmodavoiture=lookup_widget(objet, "HAspinbuttonmodavoiture");
	HAspinbuttonmodnombrevoiture=lookup_widget(objet, "HAspinbuttonmodnombrevoiture");

	HAcomboboxmodMarquevoiture=lookup_widget(objet, "HAcomboboxmodMarquevoiture");
	HAcomboboxmodPrixvoiture=lookup_widget(objet, "HAcomboboxmodPrixvoiture");


	v.HAdateresrv.HAjour= gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(HAspinbuttonmodjvoiture));
	v.HAdateresrv.HAmois= gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(HAspinbuttonmodmvoiture));
	v.HAdateresrv.HAannee= gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(HAspinbuttonmodavoiture));
	v.HAnombredujourv= gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(HAspinbuttonmodnombrevoiture));

	if (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxmodMarquevoiture))!=-1)
	{strcpy(v.HAmarquev,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxmodMarquevoiture)));}
	if (gtk_combo_box_get_active (GTK_COMBO_BOX(HAcomboboxmodPrixvoiture))!=-1)
	{strcpy(v.HAprixv,gtk_combo_box_get_active_text(GTK_COMBO_BOX(HAcomboboxmodPrixvoiture)));}


	v.HAprixtv=HAcalculprixv(v);


input6=lookup_widget(objet,"HAentryCinmodvoiture");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input6)));

output=lookup_widget(objet,"HAlabelerreurMod");

if ( (strlen(v.HANomv)==0) || (strlen(v.HAPrenomv)==0) || (strlen(v.HACinv)==0) )  
{
gtk_label_set_text(GTK_LABEL(output),"Verifier les champs vides !!");
}
else 
{
x= HAmodifiervoiture(cin, v);


if (x!=1)
{
gtk_label_set_text(GTK_LABEL(output),"Verifier votre numero de CIN/passport !!");
}
else if (x==1)
{


gtk_label_set_text(GTK_LABEL(output),"Modification a eu lieu avec succes!");
}
}
}





/*****************************************************************/


void
on_HAbuttonretourmodvoiture_clicked    (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAFenetreAffichagevoiture;
GtkWidget *HAFenetreModificationVoiture;
GtkWidget *HAtreeviewvoiture;

HAFenetreModificationVoiture=lookup_widget(objet,"HAFenetreModificationVoiture");
gtk_widget_destroy(HAFenetreModificationVoiture);

HAFenetreAffichagevoiture=lookup_widget(objet,"HAFenetreAffichagevoiture");
HAFenetreAffichagevoiture=create_HAFenetreAffichagevoiture();

gtk_widget_show(HAFenetreAffichagevoiture);
HAtreeviewvoiture=lookup_widget(HAFenetreAffichagevoiture,"HAtreeviewvoiture");

HAafficher_voiture(HAtreeviewvoiture);
}

/*****************************************************************/


void
on_HAbuttonrecherchevoiture_clicked    (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *input1,*output;
GtkWidget *HAtreeviewrecherchevoiture;

int x;
char cin[100];


input1=lookup_widget(objet,"HAentryRecherchevoiture");

output=lookup_widget(objet,"HAlabelErreurRecherchevoiture");

strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input1)));

HAtreeviewrecherchevoiture=lookup_widget(objet,"HAtreeviewrecherchevoiture");

x=HARajouter_voiture(cin);
if (x==1)
{
HARafficher_voiture(HAtreeviewrecherchevoiture);
gtk_label_set_text(GTK_LABEL(output),"Reservation trouve !!");
}
else if (x!=1)
{
gtk_label_set_text(GTK_LABEL(output),"Aucune reservation trouve, Verifier le numero de votre CIN !! ");
}
}

/*****************************************************************/


void
on_HAbuttonRetourRecherchevoiture_clicked (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAFenetreAffichagevoiture;
GtkWidget *HAFenetreRechercheVoiture;
GtkWidget *HAtreeviewvoiture;

HAFenetreRechercheVoiture=lookup_widget(objet,"HAFenetreRechercheVoiture");
gtk_widget_destroy(HAFenetreRechercheVoiture);

HAFenetreAffichagevoiture=lookup_widget(objet,"HAFenetreAffichagevoiture");
HAFenetreAffichagevoiture=create_HAFenetreAffichagevoiture();
gtk_widget_show(HAFenetreAffichagevoiture);

HAtreeviewvoiture=lookup_widget(HAFenetreAffichagevoiture,"HAtreeviewvoiture");

HAafficher_voiture(HAtreeviewvoiture);
}

/***********************************************************************************/

void
on_HAbuttonRetourResvoiture_clicked    (GtkWidget       *objet, gpointer         user_data)
{

GtkWidget *HAFenetreAffichagevoiture;
GtkWidget *HAFenetreReservationvoiture;

HAFenetreAffichagevoiture=lookup_widget(objet,"HAFenetreAffichagevoiture");
gtk_widget_destroy(HAFenetreAffichagevoiture);

HAFenetreReservationvoiture=lookup_widget(objet,"HAFenetreReservationvoiture");
HAFenetreReservationvoiture=create_HAFenetreReservationvoiture();
gtk_widget_show(HAFenetreReservationvoiture);

}



/******************************************************************/



void on_HAbuttonRetourMenu1_clicked         (GtkWidget       *objet, gpointer         user_data)
{

GtkWidget *HAFenetreReservation;
GtkWidget *HAMenuAgent;
GtkWidget *ANwindowAcceuil;

if (global==2)
{

HAFenetreReservation=lookup_widget(objet,"HAFenetreReservation");
gtk_widget_destroy(HAFenetreReservation);

HAMenuAgent=lookup_widget(objet,"HAMenuAgent");
HAMenuAgent=create_HAMenuAgent();
gtk_widget_show(HAMenuAgent);
}
else if (global ==3)
{

HAFenetreReservation=lookup_widget(objet,"HAFenetreReservation");
gtk_widget_destroy(HAFenetreReservation);

ANwindowAcceuil=lookup_widget(objet,"ANwindowAcceuil");
ANwindowAcceuil=create_ANwindowAcceuil();
gtk_widget_show(ANwindowAcceuil);
}
}

/************************************************************************************/


void
on_HAbuttonRetourMenu2_clicked         (GtkWidget       *objet, gpointer         user_data)
{

GtkWidget *HAFenetreReservationvoiture;
GtkWidget *HAMenuAgent;
GtkWidget *ANwindowAcceuil;

if (global ==2)
{
HAFenetreReservationvoiture=lookup_widget(objet,"HAFenetreReservationvoiture");
gtk_widget_destroy(HAFenetreReservationvoiture);

HAMenuAgent=lookup_widget(objet,"HAMenuAgent");
HAMenuAgent=create_HAMenuAgent();
gtk_widget_show(HAMenuAgent);
}

else if (global ==3)
{

HAFenetreReservationvoiture=lookup_widget(objet,"HAFenetreReservationvoiture");
gtk_widget_destroy(HAFenetreReservationvoiture);

ANwindowAcceuil=lookup_widget(objet,"ANwindowAcceuil");
ANwindowAcceuil=create_ANwindowAcceuil();
gtk_widget_show(ANwindowAcceuil);
}

}



/********************************************************************************/



void
on_HAbuttonAjouterPres_clicked  (GtkWidget       *objet, gpointer         user_data)
{


GtkWidget *HAMenuAgent;
GtkWidget *shajouterModifierVols;


HAMenuAgent=lookup_widget(objet,"HAMenuAgent");
gtk_widget_destroy(HAMenuAgent);

shajouterModifierVols=lookup_widget(objet,"shajouterModifierVols");
shajouterModifierVols=create_shajouterModifierVols();
gtk_widget_show(shajouterModifierVols);




}


/********************************************************************************/




void
on_HAbuttonConsulterRec_clicked      (GtkWidget       *objet, gpointer         user_data)
{

GtkWidget *HAMenuAgent;
GtkWidget *yk_window1;


HAMenuAgent=lookup_widget(objet,"HAMenuAgent");
gtk_widget_destroy(HAMenuAgent);

yk_window1=lookup_widget(objet,"yk_window1");
yk_window1=create_yk_window1();
gtk_widget_show(yk_window1);




}



/********************************************************************************/



void
on_HAbuttonDeconnexion_clicked (GtkWidget       *objet, gpointer         user_data)
{

GtkWidget *HAMenuAgent;
GtkWidget *ANwindowAuthentification;


HAMenuAgent=lookup_widget(objet,"HAMenuAgent");
gtk_widget_destroy(HAMenuAgent);

ANwindowAuthentification=lookup_widget(objet,"ANwindowAuthentification");
ANwindowAuthentification=create_ANwindowAuthentification();
gtk_widget_show(ANwindowAuthentification);





}


/***********************************************************************************/


void
on_HAbuttonFenetrevoitureTakwa_clicked (GtkWidget       *objet, gpointer         user_data)
{

GtkWidget *HAMenuAgent;
GtkWidget *locationEmptg;


HAMenuAgent=lookup_widget(objet,"HAMenuAgent");
gtk_widget_destroy(HAMenuAgent);

locationEmptg=lookup_widget(objet," locationEmptg");
locationEmptg=create_locationEmptg();
gtk_widget_show(locationEmptg);




}


/***********************************************************************************/



/******************** FIN TRAVAIL DE HEDI AROUA **********************************/



/********************************************************************************/








/***********************************************************************************/



/******************** Debut travail Arbi Nouri **********************************/



/********************************************************************************/







void
on_ANbuttonConfirmerInscription_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
char user[50], nom[50], prenom[50],cin[50], email[50], password[50],naissance[50], occupation[50], civil[50];  
int enfant ;
int n=0 ; 
char test[50]="\0";
GtkWidget *output, *outputtest;
output = lookup_widget(button,"ANlabelTestUsernameAcceuil") ;
outputtest=lookup_widget(button,"ANlabelTestInscription");


GtkWidget *input1 ,*input2, *input3,*input4,*input5,*input6,*input7,*input8,*input9, *input10; 
input1=lookup_widget(button,"ANentryUsernameInscription");
input2=lookup_widget(button,"ANentryNomInscription");
input3=lookup_widget(button,"ANentryPrenomInscription");
input4=lookup_widget(button,"ANentryEmailInscription");
input5=lookup_widget(button,"ANentryPasswordInscription");
input6=lookup_widget(button,"ANentryNaissanceInscription");
input7=lookup_widget(button,"ANcomboboxOccupationInscription");
input8=lookup_widget(button,"ANcomboboxCivilInscription");
input9=lookup_widget(button,"ANspinbuttonIEnfantInscription");
input10=lookup_widget(button,"ANentryCINInscription");

strcpy(user,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(nom,gtk_entry_get_text(GTK_ENTRY(input2))); 
strcpy(prenom,gtk_entry_get_text(GTK_ENTRY(input3))); 
strcpy(email,gtk_entry_get_text(GTK_ENTRY(input4))); 
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input5))); 
strcpy(naissance,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input10)));
strcpy(occupation,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input7)));
strcpy(civil,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input8)));
enfant=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input9));

if ( ((strcmp(user,test)==0) || (strcmp(nom,test)==0) || (strcmp(prenom,test)==0) || (strcmp(cin,test)==0) || (strcmp(email,test)==0) || (strcmp(password,test)==0) || (strcmp(naissance,test)==0) || (strcmp(occupation,test)==0) || (strcmp(civil,test)==0)) )
	{
gtk_label_set_text(GTK_LABEL(outputtest),"voulez vous remplir tout les champs !");
	}
else {
n=ajouter_client(user,nom,prenom,cin,email,naissance,password,occupation,civil,enfant);
if (n==1)
{
gtk_label_set_text(GTK_LABEL(output),"Ce nom d'utilisateur déja utilisé !");
}
else 
{

GtkWidget *window;
GtkWidget *window1;	

window = lookup_widget(button,"ANwindowInscription") ;
gtk_widget_hide (window);
window1 = create_ANwindowInscirptionConfirmer();
gtk_widget_show (window1);
}
}
}


void
on_ANbuttonSeconnecterAuthentification_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *output;
GtkWidget *window;
GtkWidget *window1;
GtkWidget *ANtreeviewHistoriqueAcceuil;



char user[50],password[50],out[100];
int role;
int x;

input1 = lookup_widget(button,"ANentryUsernameAuthentification") ;
input2 = lookup_widget(button,"ANentryPasswordAuthentification") ;
output = lookup_widget(button,"ANlabelErreurAuthentification") ;
ANtreeviewHistoriqueAcceuil = lookup_widget(button,"ANtreeviewHistoriqueAcceuil") ;

strcpy(user,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input2)));

role = authentification(user,password);

window = lookup_widget(button,"ANwindowAuthentification") ;
if (role==3){
		global=3;
	gtk_widget_hide(window);
	window1 = create_ANwindowAcceuil ();
  	gtk_widget_show (window1);

	x=ANhistorique_vol ();

		if (x==1)
		{

		ANtreeviewHistoriqueAcceuil = lookup_widget(window1,"ANtreeviewHistoriqueAcceuil") ;
		ANafficher_vol(ANtreeviewHistoriqueAcceuil);
		}
	}
else if (role==2){
		global=2;
	gtk_widget_hide(window);
	window1 = create_HAMenuAgent ();
  	gtk_widget_show (window1);
	}
else if (role==1){
		global=1;
	gtk_widget_hide(window);
	window1 = create_NHwindow1 ();
  	gtk_widget_show (window1);
	}
else {
	strcpy(out,"Mot de passe ou nom d'utilisateur est incorrect !");
	}

gtk_label_set_text(GTK_LABEL(output),out);
}



void
on_ANbuttonInscriptionAuthentification_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
GtkWidget *window1;	

window = lookup_widget(button,"ANwindowAuthentification") ;
gtk_widget_hide (window);
window1 = create_ANwindowInscription();
gtk_widget_show (window1);
}


void
on_ANbuttonAnnulerInscription_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
GtkWidget *window1;	

window = lookup_widget(button,"ANwindowInscription") ;
gtk_widget_hide (window);
window1 = create_ANwindowAuthentification();
gtk_widget_show (window1);
}


void
on_ANbuttonDeconnecterAcceuil_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
GtkWidget *window1;	

window = lookup_widget(button,"ANwindowAcceuil") ;
gtk_widget_destroy (window);
window1 = create_ANwindowAuthentification();
gtk_widget_show (window1);
}




GtkWidget *window10;
void
on_ANbuttonSuppcompte_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;


window10=lookup_widget(button,"ANwindowAcceuil");

window = create_ANdialogSupprimerCompte ();
gtk_widget_show (window);

}


void
on_ANcancelbuttonSupprimerCompte_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;	

window = lookup_widget(button,"ANdialogSupprimerCompte");
gtk_widget_destroy (window);

}



void on_ANokbuttonSupprimerCompte_clicked   (GtkButton       *button,
                                              gpointer         user_data)
{

GtkWidget *window1;
GtkWidget *window2;
GtkWidget *input;

char user[50],password[50];

window1=lookup_widget(button,"ANdialogSupprimerCompte");
window2=create_ANwindowAuthentification() ;
gtk_widget_show(window2); 
gtk_widget_hide(window1);
gtk_widget_hide(window10);

input=lookup_widget(button,"ANentryUsernameSupprimer");
strcpy(user,gtk_entry_get_text(GTK_ENTRY(input)));

supprimer_client(user);
}


void
on_ANbuttonModifProfil_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_ANwindowModifProfil();
gtk_widget_show(window);

}


void
on_ANbuttonAnnulerModif_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=lookup_widget(button,"ANwindowModifProfil");
gtk_widget_destroy(window);
}


void
on_ANbuttonConfirmerModif_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
char user[50]; 
char email[50]; 
char password[50];
char occupation[50]; 
char civil[50]; 
int enfant ; 
GtkWidget *input0,*input1,*input2,*input3,*input4,*input5 ;

input0=lookup_widget(button,"entryuserrr");
input1=lookup_widget(button,"ANentryMailClientModif");
input2=lookup_widget(button,"ANentryPasswordClientModif");
input3=lookup_widget(button,"ANcomboboxOccupationModif");
input4=lookup_widget(button,"ANcomboboxCivilModif");
input5=lookup_widget(button,"ANspinbuttonEnfantModif");


strcpy(user,gtk_entry_get_text(GTK_ENTRY(input0))); 
strcpy(email,gtk_entry_get_text(GTK_ENTRY(input1))); 
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input2))); 

strcpy(occupation,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));
strcpy(civil,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input4)));
enfant=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));

modification_profil_client (user,email,password,occupation,civil,enfant) ;

GtkWidget *window;
window=lookup_widget(button,"ANwindowModifProfil");
gtk_widget_destroy(window);



}


void
on_ANbuttonAfficherAcceuil_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{


GtkWidget *output10;
GtkWidget *output11;
GtkWidget *output12;
GtkWidget *output13;
GtkWidget *output14;
GtkWidget *output15;
GtkWidget *output16;
GtkWidget *output17;
GtkWidget *output18;


char user1[50];
char nom1[50];
char prenom1[50];
char email1[50];
char cin1[50];
char naissance1[50];
char password1[50];
char occupation1[50];
char civil1[50];
char enfant1[50];
int r ;

output10=lookup_widget(button,"ANlabelUsernameAcceuil");
output11=lookup_widget(button,"ANlabelNomAcceuil");
output12=lookup_widget(button,"ANlabelPrenomAcceuil");
output13=lookup_widget(button,"ANlabelCINAcceuil");
output14=lookup_widget(button,"ANlabelMailAcceuil");
output15=lookup_widget(button,"ANlabelNaissanceAcceuil");
output16=lookup_widget(button,"ANlabelOccupationAcceuil");
output17=lookup_widget(button,"ANlabelCivilAcceuil");
output18=lookup_widget(button,"ANlabelNbrEnfantAcceuil");

FILE *f;
f=fopen("fiche_cnx.txt","r");
		if(f!=NULL)
		{
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %d \n",user1,nom1,prenom1,cin1,email1,password1,naissance1,occupation1,civil1,enfant1,&r)!=EOF)
			{
				gtk_label_set_text(GTK_LABEL(output10),user1);
				gtk_label_set_text(GTK_LABEL(output12),nom1);
				gtk_label_set_text(GTK_LABEL(output11),prenom1);
				gtk_label_set_text(GTK_LABEL(output13),cin1);
				gtk_label_set_text(GTK_LABEL(output14),email1);
				gtk_label_set_text(GTK_LABEL(output15),naissance1);
				gtk_label_set_text(GTK_LABEL(output16),occupation1);
				gtk_label_set_text(GTK_LABEL(output17),civil1);
				gtk_label_set_text(GTK_LABEL(output18),enfant1);		
			}
		}

fclose(f);
}



void
on_ANbuttonInscriptionreusite_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *window;
GtkWidget *window1;	

window = lookup_widget(button,"ANwindowInscirptionConfirmer") ;
gtk_widget_hide (window);
window1 = create_ANwindowAuthentification();
gtk_widget_show (window1);


}


/********************************************************************************/

/*********************** Debut travail Yosri **********************************/

/*******************************************************************************/


void on_yk_rectifier_clicked                (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *yk_window1;
GtkWidget *yk_window5;

yk_window1=lookup_widget(objet,"yk_window1");

gtk_widget_hide(yk_window1);
yk_window5=lookup_widget(objet,"yk_window5");
yk_window5=create_yk_window5();
gtk_widget_show(yk_window5);
}


void
on_yk_supprimer_clicked                (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *yk_window1;
GtkWidget *yk_window3;

yk_window1=lookup_widget(objet,"yk_window1");

gtk_widget_hide(yk_window1);
yk_window3=lookup_widget(objet,"yk_window3");
yk_window3=create_yk_window3();
gtk_widget_show(yk_window3);
}


void
on_yk_ajouter_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{
reclamation p;
GtkWidget *input1,*input2,*input3;
GtkWidget *output1,*output2,*output3;
GtkWidget *yk_type;
GtkWidget *output;

char empty[]="\0";

GtkWidget *yk_window1;

yk_window1=lookup_widget(objet,"yk_window1");

output1=lookup_widget(objet,"yk_label44");
output2=lookup_widget(objet,"yk_label45");
output3=lookup_widget(objet,"yk_label46");

yk_type=lookup_widget(objet,"yk_type");
input1=lookup_widget(objet,"yk_date");
input2=lookup_widget(objet,"yk_id");
input3=lookup_widget(objet,"yk_avis");

strcpy(p.yk_date,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.yk_id,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.yk_avis,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.yk_type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(yk_type)));

if(strcmp(p.yk_date,empty)==0)
{gtk_label_set_text(GTK_LABEL(output1),"Vérifier le remplissage");}

else if(strcmp(p.yk_id,empty)==0)
{gtk_label_set_text(GTK_LABEL(output2),"Vérifier le remplissage");}

else if(strcmp(p.yk_avis,empty)==0)
{gtk_label_set_text(GTK_LABEL(output3),"Vérifier le remplissage");}

else
{
ajouter_reclamation(p);
}
output=lookup_widget(objet,"yk_label33");
gtk_label_set_text(GTK_LABEL(output),"Réclamation envoyée");

}


void on_yk_afficher_clicked                 (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *yk_window1;
GtkWidget *yk_window2;
GtkWidget *yk_treeview1;

yk_window1=lookup_widget(objet,"yk_window1");

gtk_widget_destroy(yk_window1);
yk_window2=lookup_widget(objet,"yk_window2");
yk_window2=create_yk_window2();

gtk_widget_show(yk_window2);

yk_treeview1=lookup_widget(yk_window2,"yk_treeview1");

afficher_reclamation(yk_treeview1);
}


void on_yk_retour1_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *yk_window1,*yk_window2;

yk_window2=lookup_widget(objet,"yk_window2");

gtk_widget_hide(yk_window2);
yk_window1=create_yk_window1();
gtk_widget_show(yk_window1);
}


void on_yk_confirmer_clicked                (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *yk_window3;
GtkWidget *yk_id1;

GtkWidget *input1;

input1=lookup_widget(objet,"yk_id1");

yk_id1=gtk_entry_get_text(GTK_ENTRY(input1));
supprimer_reclamation(yk_id1);
}


void on_yk_retour3_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *yk_window1,*yk_window3;

yk_window3=lookup_widget(objet,"yk_window3");

gtk_widget_hide(yk_window3);
yk_window1=create_yk_window1();
gtk_widget_show(yk_window1);
}


void on_yk_button2_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{
reclamation p;
GtkWidget *input1,*input2,*input3;
GtkWidget *yk_type;
GtkWidget *output;

char empty[]="\0";

GtkWidget *yk_window5;

yk_window5=lookup_widget(objet,"yk_window5");


yk_type=lookup_widget(objet,"yk_typer");
input1=lookup_widget(objet,"yk_dater");
input2=lookup_widget(objet,"yk_idr");
input3=lookup_widget(objet,"yk_avisr");

strcpy(p.yk_date,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.yk_id,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.yk_avis,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.yk_type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(yk_type)));


ajouter_reclamation(p);
output=lookup_widget(objet,"yk_label43");
gtk_label_set_text(GTK_LABEL(output),"Modification envoyée");

}


void on_yk_button1_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *yk_window3;
GtkWidget *yk_idr;

GtkWidget *input1;

input1=lookup_widget(objet,"yk_idr");

yk_idr=gtk_entry_get_text(GTK_ENTRY(input1));
supprimer_reclamation(yk_idr);
}


void on_yk_button3_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *yk_window1,*yk_window5;

yk_window5=lookup_widget(objet,"yk_window5");

gtk_widget_hide(yk_window5);
yk_window1=create_yk_window1();
gtk_widget_show(yk_window1);
}

/************************************************************************************/

/************************ Debut travail de Nawress **********************************/

/**********************************************************************************/

void
on_NHajouter_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *NHNom;
GtkWidget *NHPrenom;
GtkWidget *NHJour;
GtkWidget *NHMois; 
GtkWidget *NHAnnee;
GtkWidget *NHCombobox1; 
GtkWidget *NHMail;

GtkWidget *NHwindow1;

GtkWidget *NHsortie;
Personne p;
NHwindow1=lookup_widget(objet, "NHwindow1");

NHNom=lookup_widget(objet, "NHentry1");
NHPrenom=lookup_widget(objet, "NHentry2");
NHJour=lookup_widget(objet, "jour");
NHMois=lookup_widget(objet, "mois");
NHAnnee=lookup_widget(objet, "annee");
NHCombobox1=lookup_widget(objet, "NHcombobox1");
NHMail=lookup_widget(objet, "NHentry3");
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(NHNom)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(NHPrenom)));
p.dt.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(NHJour));
p.dt.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(NHMois));
p.dt.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(NHAnnee));

strcpy(p.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(NHCombobox1)));
strcpy(p.mail,gtk_entry_get_text(GTK_ENTRY(NHMail)));
ajouter_personne (p);
NHsortie=lookup_widget(objet,"NHlabel26");
gtk_label_set_text(GTK_LABEL(NHsortie),"Ajoutation réussite.");
}


void
on_NHafficher_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

	GtkWidget *NHwindow1;
	GtkWidget *NHwindow2;
	GtkWidget *NHtreeview1;

	NHwindow1=lookup_widget(objet, "NHwindow1");

	gtk_widget_destroy(NHwindow1);
	NHwindow2=lookup_widget(objet,"NHwindow2");
	NHwindow2=create_NHwindow2();

	gtk_widget_show(NHwindow2);

	NHtreeview1=lookup_widget(NHwindow2,"NHtreeview1");
	afficher_personne(NHtreeview1);

}


void
on_NHretour_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *NHwindow1, *NHwindow2;
NHwindow2=lookup_widget(objet,"NHwindow2");

gtk_widget_destroy(NHwindow2);
NHwindow1=create_NHwindow1();
gtk_widget_show(NHwindow1);
}


void
on_NHsupprimer_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
char mail[200];
GtkWidget *recherche ;

recherche=lookup_widget(objet,"NHentrymail");


strcpy(mail,gtk_entry_get_text(GTK_ENTRY(recherche)));

supprimer_personne(mail);
}


void
on_NHmodifier_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *NHwindow2 ,*NHwindow3 ;


NHwindow2=lookup_widget(objet,"NHwindow2");

gtk_widget_destroy(NHwindow2);
NHwindow3=create_NHwindow3();
gtk_widget_show(NHwindow3);
}


void
on_NHretour1_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *NHwindow3, *NHwindow2;
NHwindow3=lookup_widget(objet,"NHwindow3");

gtk_widget_destroy(NHwindow3);
NHwindow2=create_NHwindow2();
gtk_widget_show(NHwindow2);
}


void
on_NHvalider_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
char mail[30];
NewPersonne p1 ;
GtkWidget *pnom ,*pprenom ,*pdate ,*psexe ,*pmail ;
GtkWidget *NHwindow3 ;
GtkWidget *entrer;
entrer=lookup_widget(objet,"NHentrymail1");
NHwindow3=lookup_widget(objet,"NHwindow3");



pnom=lookup_widget(objet,"NHentry4");
pprenom=lookup_widget(objet,"NHentry5");
pdate=lookup_widget(objet,"NHentry6");
psexe=lookup_widget(objet,"NHcombobox2");
pmail=lookup_widget(objet,"NHentry7");
strcpy(mail,gtk_entry_get_text(GTK_ENTRY(entrer)));
strcpy(p1.nom1,gtk_entry_get_text(GTK_ENTRY(pnom)));
strcpy(p1.prenom1,gtk_entry_get_text(GTK_ENTRY(pprenom)));
strcpy(p1.naissance1,gtk_entry_get_text(GTK_ENTRY(pdate)));
strcpy(p1.sexe1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(psexe)));
strcpy(p1.mail1,gtk_entry_get_text(GTK_ENTRY(pmail)));
modifier_personne(mail,p1);
}


/*************************************************************************************/

/********************* Debut travail Salmen ********************************************/

/*****************************************************************************************/


void
on_shAfficher_clicked                  (GtkWidget       *shobjet,
                                        gpointer         user_data)
{
GtkWidget *ajouterModifierVols;
GtkWidget *ListeVols;
GtkWidget *shtreeview;

ajouterModifierVols=lookup_widget(shobjet,"shajouterModifierVols");
gtk_widget_destroy(ajouterModifierVols);
ListeVols=lookup_widget(shobjet,"shListeVols");
ListeVols=create_shListeVols();
gtk_widget_show(ListeVols);
shtreeview=lookup_widget(ListeVols,"shtreeview");
shAfficherVols(shtreeview);
}


void
on_shok2_clicked                       (GtkWidget       *shobjet,
                                        gpointer         user_data)
{
GtkWidget *Combobox1;
GtkWidget *Combobox2;
GtkWidget *Combobox3;
GtkWidget *ajouterModifierVols;
GtkWidget *msg;

char shville[20][20];
char shpays[20];
char shpaysde[20];
int shi;
ajouterModifierVols=lookup_widget(shobjet,"shajouterModifierVols");
msg=lookup_widget(shobjet,"shmessage");
Combobox1=lookup_widget(shobjet,"shPaysA");
Combobox2=lookup_widget(shobjet,"shVilleA");
Combobox3=lookup_widget(shobjet,"shPaysDe");
strcpy(shpays,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox1)));
strcpy(shpaysde,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox3)));
if (strcmp(shpaysde,shpays)!=0)
{shRemplirVille(shville,shpays);
gtk_label_set_text(GTK_LABEL(msg)," ");
for(shi=1;shi<=3;shi++)
gtk_combo_box_remove_text (GTK_COMBO_BOX (Combobox2),0);
for(shi=0;shi<3;shi++)
gtk_combo_box_append_text (GTK_COMBO_BOX (Combobox2),_(shville[shi]));
}
else
gtk_label_set_text(GTK_LABEL(msg),"choisir une autre destination!!");
}


void
on_shok1_clicked                       (GtkWidget       *shobjet,
                                        gpointer         user_data)
{
GtkWidget *Combobox1;
GtkWidget *Combobox2;
GtkWidget *Combobox3;
char shville[20][20];
char shcompagnie[20][20];
char shpays[20];
int shi;
Combobox1=lookup_widget(shobjet,"shPaysDe");
Combobox2=lookup_widget(shobjet,"shVilleDe");
Combobox3=lookup_widget(shobjet,"shCompagnie");
strcpy(shpays,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox1)));
shRemplirVille(shville,shpays);
shRemplirCompagnie(shcompagnie,shpays);
for(shi=0;shi<=3;shi++)
gtk_combo_box_remove_text (GTK_COMBO_BOX (Combobox2),0);
for(shi=0;shi<3;shi++)
gtk_combo_box_append_text (GTK_COMBO_BOX (Combobox2),_(shville[shi]));
for(shi=0;shi<=2;shi++)
gtk_combo_box_remove_text (GTK_COMBO_BOX (Combobox3),0);
for(shi=0;shi<2;shi++)
gtk_combo_box_append_text (GTK_COMBO_BOX (Combobox3),_(shcompagnie[shi]));
}


void
on_shSupprimer_clicked                 (GtkWidget       *shobjet,
                                        gpointer         user_data)
{
GtkWidget *ListeVols;
GtkWidget *combobox;
GtkWidget *label;
GtkWidget *treeview;

char ref[20];
ListeVols=lookup_widget(shobjet,"shListeVols");
combobox=lookup_widget(shobjet,"shvolsbox");
label=lookup_widget(shobjet,"shmsgsupression");
strcpy(ref,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));
shSupprimerVol(ref);
gtk_widget_destroy(ListeVols);
ListeVols=create_shListeVols();
gtk_widget_show(ListeVols);
treeview=lookup_widget(ListeVols,"shtreeview");
shAfficherVols(treeview);
gtk_label_set_text(GTK_LABEL(label),"supression reussite !!");
}


void
on_shchoisir_clicked                   (GtkWidget       *shobjet,
                                        gpointer         user_data)
{
GtkWidget *Combobox0;
GtkWidget *ListeVols;
char shtabvol[20][20];
int shn,shi;
ListeVols=lookup_widget(shobjet,"shListeVols");
Combobox0=lookup_widget(shobjet,"shvolsbox");
shn=shRemplirVols(shtabvol);
for(shi=0;shi<=shn;shi++)
gtk_combo_box_remove_text (GTK_COMBO_BOX (Combobox0),0);
for(shi=0;shi<shn;shi++)
gtk_combo_box_append_text (GTK_COMBO_BOX (Combobox0),_(shtabvol[shi]));
}


void
on_shretour_clicked                    (GtkWidget       *shobjet,
                                        gpointer         user_data)
{
GtkWidget *ajouterModifierVols,*ListeVols;
ListeVols=lookup_widget(shobjet,"shListeVols");
gtk_widget_destroy(ListeVols);
ajouterModifierVols=create_shajouterModifierVols();
gtk_widget_show(ajouterModifierVols);
}


void
on_shModifier_clicked                  (GtkWidget       *shobjet,
                                        gpointer         user_data)
{
GtkWidget *ajouterModifierVols;
GtkWidget *Ref;
GtkWidget *paysde;
GtkWidget *villede;
GtkWidget *paysa;
GtkWidget *villea;
GtkWidget *jourallez;
GtkWidget *moisallez;
GtkWidget *anneeallez;
GtkWidget *jourretour;
GtkWidget *moisretour;
GtkWidget *anneeretour;
GtkWidget *compagnie;
GtkWidget *npassagers;
GtkWidget *prix;
GtkWidget *msg;
shVol v;
char prixc[10];
ajouterModifierVols=lookup_widget(shobjet,"shajouterModifierVols");
Ref=lookup_widget(shobjet,"shref");
paysde=lookup_widget(shobjet,"shPaysDe");
villede=lookup_widget(shobjet,"shVilleDe");
paysa=lookup_widget(shobjet,"shPaysA");
villea=lookup_widget(shobjet,"shVilleA");
jourallez=lookup_widget(shobjet,"shja");
moisallez=lookup_widget(shobjet,"shma");
anneeallez=lookup_widget(shobjet,"shaa");
jourretour=lookup_widget(shobjet,"shjr");
moisretour=lookup_widget(shobjet,"shmr");
anneeretour=lookup_widget(shobjet,"shar");
compagnie=lookup_widget(shobjet,"shCompagnie");
npassagers=lookup_widget(shobjet,"shnbpassager");
prix=lookup_widget(shobjet,"shprix");
msg=lookup_widget(shobjet,"shmessagemodifier");
strcpy(v.shRef,gtk_entry_get_text(GTK_ENTRY(Ref)));
strcpy(prixc,gtk_entry_get_text(GTK_ENTRY(prix)));
v.shPrix=atoi(prixc);
strcpy(v.shDe.shpays,gtk_combo_box_get_active_text(GTK_COMBO_BOX(paysde)));
strcpy(v.shDe.shville,gtk_combo_box_get_active_text(GTK_COMBO_BOX(villede)));
strcpy(v.shA.shpays,gtk_combo_box_get_active_text(GTK_COMBO_BOX(paysa)));
strcpy(v.shA.shville,gtk_combo_box_get_active_text(GTK_COMBO_BOX(villea)));
strcpy(v.shCompagnieaerienne,gtk_combo_box_get_active_text(GTK_COMBO_BOX(compagnie)));
v.shdateallez.shj=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(jourallez));
v.shdateallez.shm=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(moisallez));
v.shdateallez.sha=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(anneeallez));
v.shdateretour.shj=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(jourretour));
v.shdateretour.shm=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(moisretour));
v.shdateretour.sha=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(anneeretour));
v.shNombredesiege=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(npassagers));
if (shVerifierVol(v.shRef)==1 && shVerifierDate(v.shdateallez,v.shdateretour)==1)
{shModifierVol(v);
gtk_label_set_text(GTK_LABEL(msg),"modification reussite !!");}
else
{if (shVerifierVol(v.shRef)==0)
{gtk_label_set_text(GTK_LABEL(msg),"vol inexistant!!");}

if (shVerifierDate(v.shdateallez,v.shdateretour)==0)
gtk_label_set_text(GTK_LABEL(msg),"verifier date!!");}
}


void
on_shAjouter_clicked                   (GtkWidget      *shobjet,
                                        gpointer         user_data)
{
GtkWidget *ajouterModifierVols;
GtkWidget *Ref;
GtkWidget *paysde;
GtkWidget *villede;
GtkWidget *paysa;
GtkWidget *villea;
GtkWidget *jourallez;
GtkWidget *moisallez;
GtkWidget *anneeallez;
GtkWidget *jourretour;
GtkWidget *moisretour;
GtkWidget *anneeretour;
GtkWidget *compagnie;
GtkWidget *npassagers;
GtkWidget *prix;
GtkWidget *msg;
shVol shv;
char prixc[10];
ajouterModifierVols=lookup_widget(shobjet,"shajouterModifierVols");
Ref=lookup_widget(shobjet,"shref");
paysde=lookup_widget(shobjet,"shPaysDe");
villede=lookup_widget(shobjet,"shVilleDe");
paysa=lookup_widget(shobjet,"shPaysA");
villea=lookup_widget(shobjet,"shVilleA");
jourallez=lookup_widget(shobjet,"shja");
moisallez=lookup_widget(shobjet,"shma");
anneeallez=lookup_widget(shobjet,"shaa");
jourretour=lookup_widget(shobjet,"shjr");
moisretour=lookup_widget(shobjet,"shmr");
anneeretour=lookup_widget(shobjet,"shar");
compagnie=lookup_widget(shobjet,"shCompagnie");
npassagers=lookup_widget(shobjet,"shnbpassager");
prix=lookup_widget(shobjet,"shprix");
msg=lookup_widget(shobjet,"shmessageajouter");
strcpy(shv.shRef,gtk_entry_get_text(GTK_ENTRY(Ref)));
strcpy(prixc,gtk_entry_get_text(GTK_ENTRY(prix)));
shv.shPrix=atoi(prixc);
strcpy(shv.shDe.shpays,gtk_combo_box_get_active_text(GTK_COMBO_BOX(paysde)));
strcpy(shv.shDe.shville,gtk_combo_box_get_active_text(GTK_COMBO_BOX(villede)));
strcpy(shv.shA.shpays,gtk_combo_box_get_active_text(GTK_COMBO_BOX(paysa)));
strcpy(shv.shA.shville,gtk_combo_box_get_active_text(GTK_COMBO_BOX(villea)));
strcpy(shv.shCompagnieaerienne,gtk_combo_box_get_active_text(GTK_COMBO_BOX(compagnie)));
shv.shdateallez.shj=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(jourallez));
shv.shdateallez.shm=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(moisallez));
shv.shdateallez.sha=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(anneeallez));
shv.shdateretour.shj=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(jourretour));
shv.shdateretour.shm=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(moisretour));
shv.shdateretour.sha=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(anneeretour));
shv.shNombredesiege=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(npassagers));
if (shVerifierVol(shv.shRef)==0 && shVerifierDate(shv.shdateallez,shv.shdateretour)==1)
{shAjouterVol(shv);
gtk_label_set_text(GTK_LABEL(msg),"ajout reussi !!");}
else 
{if (shVerifierVol(shv.shRef)==1)
gtk_label_set_text(GTK_LABEL(msg),"vol déja existant!!");
if (shVerifierDate(shv.shdateallez,shv.shdateretour)==0)
gtk_label_set_text(GTK_LABEL(msg),"verifier date!!");}

}

/*************************************************************************/

/******************* debut Travail Takwa ********************************/

/*************************************************************************/



void
on_buttonsupprimertg_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char marque[2000];
GtkWidget *recherche ;

recherche=lookup_widget(objet_graphique,"entryrecherchetg");


strcpy(marque,gtk_entry_get_text(GTK_ENTRY(recherche)));

supprimerlocation(marque);
}


void
on_buttonmodifertg_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char marque[2000];
GtkWidget *emp ,*modif ,*recherche;

recherche=lookup_widget(objet_graphique,"entryrecherchetg");

emp=lookup_widget(objet_graphique,"locationEmptg");
modif=create_Modifierlocationtg();
gtk_widget_show(modif);
gtk_widget_hide(emp);

strcpy(marque,gtk_entry_get_text(GTK_ENTRY(recherche)));
}


void
on_buttonajoutertg_clicked             (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *emp ,*ajout ;

emp=lookup_widget(objet_graphique,"locationEmptg");
ajout=create_ajouterloctg();
gtk_widget_show(ajout);
gtk_widget_hide(emp);
}


void
on_buttonaffichagetg_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *emploc,*treeview;

emploc=lookup_widget(objet_graphique,"locationEmptg");



treeview=lookup_widget(emploc,"treeviewloctg");
afficherlocation(treeview) ; 
}


void
on_buttonvaliderloctg_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE *f ; 
loc l ; 
GtkWidget *inputmarque , *inputprix ;
GtkWidget *emp ,*ajout ;

ajout=lookup_widget(objet_graphique,"ajouterloctg");
emp=create_locationEmptg();
gtk_widget_show(emp);
gtk_widget_hide(ajout); 

inputmarque=lookup_widget(objet_graphique,"entrymarquetg"); 
inputprix=lookup_widget(objet_graphique,"entryprixtg"); 

strcpy(l.marque,gtk_entry_get_text(GTK_ENTRY(inputmarque)));
strcpy(l.prix,gtk_entry_get_text(GTK_ENTRY(inputprix)));
ajouterlocation(l) ; 
}


void
on_buttonvaliderprixtg_clicked         (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
char nouveau[50];
char marque[2000];
GtkWidget *nprix,*ancienmarque;
GtkWidget *emp ,*modif ;

modif=lookup_widget(objet_graphique,"Modifierlocationtg");
emp=create_locationEmptg();
gtk_widget_show(emp);
gtk_widget_hide(modif);
nprix=lookup_widget(objet_graphique,"entrynouveauprixtg");
ancienmarque=lookup_widget(objet_graphique,"TKentry1");

strcpy(nouveau,gtk_entry_get_text(GTK_ENTRY(nprix)));
strcpy(marque,gtk_entry_get_text(GTK_ENTRY(ancienmarque)));
modifierlocation(marque,nouveau);
}


/************************************************************************/



void
on_YKbuttonretourMenu_clicked          (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAMenuAgent;
GtkWidget *yk_window1;
GtkWidget *ANwindowAcceuil;

if (global==2)
{
yk_window1=lookup_widget(objet,"yk_window1");
gtk_widget_destroy(yk_window1);

HAMenuAgent=lookup_widget(objet,"HAMenuAgent");
HAMenuAgent=create_HAMenuAgent();
gtk_widget_show(HAMenuAgent);
}
else if (global==3)
{
yk_window1=lookup_widget(objet,"yk_window1");
gtk_widget_destroy(yk_window1);

ANwindowAcceuil=lookup_widget(objet,"ANwindowAcceuil");
ANwindowAcceuil=create_ANwindowAcceuil();
gtk_widget_show(ANwindowAcceuil);
}
}


/************************************************************************/



void
on_SHbuttonretourMenu_clicked          (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAMenuAgent;
GtkWidget *shajouterModifierVols;


shajouterModifierVols=lookup_widget(objet,"shajouterModifierVols");
gtk_widget_destroy(shajouterModifierVols);

HAMenuAgent=lookup_widget(objet,"HAMenuAgent");
HAMenuAgent=create_HAMenuAgent();
gtk_widget_show(HAMenuAgent);
}


/************************************************************************/


void
on_TGbuttonretourMenu_clicked         (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAMenuAgent;
GtkWidget *locationEmptg;


locationEmptg=lookup_widget(objet,"locationEmptg");
gtk_widget_destroy(locationEmptg);

HAMenuAgent=lookup_widget(objet," HAMenuAgent");
HAMenuAgent=create_HAMenuAgent();
gtk_widget_show(HAMenuAgent);




}








/***********************************************************************************/




void
on_ANreservervol_clicked               (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *HAFenetreReservation;
GtkWidget *ANwindowAcceuil;

ANwindowAcceuil=lookup_widget(objet,"ANwindowAcceuil");
gtk_widget_destroy(ANwindowAcceuil);

HAFenetreReservation=lookup_widget(objet,"HAFenetreReservation");
HAFenetreReservation=create_HAFenetreReservation();
gtk_widget_show(HAFenetreReservation);
}


 /***************************************************************************************/




void
on_ANreservervoiture_clicked           (GtkWidget       *objet, gpointer         user_data)
{

GtkWidget *HAFenetreReservationvoiture;
GtkWidget *ANwindowAcceuil;

ANwindowAcceuil=lookup_widget(objet,"ANwindowAcceuil");
gtk_widget_destroy(ANwindowAcceuil);

HAFenetreReservationvoiture=lookup_widget(objet,"HAFenetreReservationvoiture");
HAFenetreReservationvoiture=create_HAFenetreReservationvoiture();
gtk_widget_show(HAFenetreReservationvoiture);

}

/***************************************************************************************/










void
on_ANbuttonR__clamation_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *ANwindowAcceuil;
GtkWidget *yk_window1;


ANwindowAcceuil=lookup_widget(button,"ANwindowAcceuil");
gtk_widget_destroy(ANwindowAcceuil);

yk_window1=lookup_widget(button,"yk_window1");
yk_window1=create_yk_window1();
gtk_widget_show(yk_window1);


}





void
on_ANbuttuonretouracceuil_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ANwindowAuthentification;
GtkWidget *NHwindow1;


NHwindow1=lookup_widget(button,"NHwindow1");
gtk_widget_destroy(NHwindow1);

ANwindowAuthentification=lookup_widget(button,"ANwindowAuthentification");
ANwindowAuthentification=create_ANwindowAuthentification();
gtk_widget_show(ANwindowAuthentification);
}

