#include <gtk/gtk.h>



void on_HAbuttonAfficher_clicked    (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonAjout_clicked      (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonModifier_clicked     (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonSupprimer_clicked     (GtkWidget       *objet, gpointer         selection);

void on_HAbuttonRetour_clicked     (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonRemplir_clicked      (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonConfirmerp_clicked     (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonConfirmerd_clicked     (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonOK3_clicked     (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonConfirmerDepart3_clicked     (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonConfirmerDestination3_clicked     (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonApply3_clicked     (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonRetour3_clicked     (GtkWidget       *objet, gpointer         user_data);



void on_HAbuttonReserverVol_clicked         (GtkWidget       *objet, gpointer         user_data);


void on_HAbuttonReservervoiture_clicked     (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonAjouterPres_clicked        (GtkWidget       *objet, gpointer         user_data);


void on_HAbuttonConsulterRec_clicked        (GtkWidget       *objet, gpointer         user_data);


void on_HAbuttonDeconnexion_clicked        (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonRetourMenu1_clicked         (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonFenetreRech_clicked         (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonRechercheVol_clicked        (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonRetourRechercheVol_clicked  (GtkWidget       *objet, gpointer         user_data);


/***********************************************************************************/

void
on_HAbuttonConfirmMarque_clicked       (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonRemplirmarque_clicked       (GtkWidget       *objet, gpointer         user_data);

void
on_Habuttonajoutervoiture_clicked     (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonAffichervoiture_clicked    (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonRetourResvoiture_clicked    (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonmodifiervoiture_clicked     (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonSupprimervoiture_clicked    (GtkWidget       *objet, gpointer         selection);

void
on_HAbuttonRecherchevoiture_clicked    (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonconfirmmodmarque_clicked    (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonConfirmmodCin_clicked       (GtkWidget       *objet, gpointer         user_data);


void
on_HAbuttonApplymodvoiture_clicked     (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonretourmodvoiture_clicked    (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonrecherchevoiture_clicked   (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonRetourRecherchevoiture_clicked  (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonRetourMenu2_clicked       (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonFenetrevoitureTakwa_clicked (GtkWidget       *objet, gpointer         user_data);

/*************************************************************************************/


/************************** Fin Travail HEDI AROUA *****************************************/

/*************************************************************************************/






/***********************************************************************************/



/******************** Debut travail Arbi Nouri **********************************/



/********************************************************************************/

void
on_ANbuttonConfirmerInscriptio_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttonSeconnecterAuthentification_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttonInscriptionAuthentification_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttonAnnulerInscription_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttonDeconnecterAcceuil_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttonConfirmerInscription_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttonSuppcompte_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANcancelbuttonSupprimerCompte_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANokbuttonSupprimerCompte_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttonModifProfil_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttonAnnulerModif_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttonConfirmerModif_clicked      (GtkButton       *button,
                                        gpointer         user_data);

/******************************************************************************/

/*************** Debut travail Yosri *******************************************/

/********************************************************************************/

void
on_yk_rectifier_clicked                (GtkButton       *objet,
                                        gpointer         user_data);

void
on_yk_supprimer_clicked                (GtkButton       *objet,
                                        gpointer         user_data);

void
on_yk_ajouter_clicked                  (GtkButton       *objet,
                                        gpointer         user_data);

void
on_yk_afficher_clicked                 (GtkButton       *objet,
                                        gpointer         user_data);

void
on_yk_retour1_clicked                  (GtkButton       *objet,
                                        gpointer         user_data);

void
on_yk_confirmer_clicked                (GtkButton       *objet,
                                        gpointer         user_data);

void
on_yk_retour3_clicked                  (GtkButton       *objet,
                                        gpointer         user_data);

void
on_yk_button2_clicked                  (GtkButton       *objet,
                                        gpointer         user_data);

void
on_yk_button1_clicked                  (GtkButton       *objet,
                                        gpointer         user_data);

void
on_yk_button3_clicked                  (GtkButton       *objet,
                                        gpointer         user_data);


/**************************************************************************/

/********************* Debut Travail Nawress *******************************/

/****************************************************************************/



                                        

void
on_NHajouter_clicked                   (GtkWidget *objet, gpointer user_data);

void
on_NHafficher_clicked                 (GtkWidget *objet, gpointer user_data);

void
on_NHretour_clicked                    (GtkWidget *objet, gpointer user_data);

void
on_NHsupprimer_clicked                (GtkWidget *objet, gpointer user_data);

void
on_NHmodifier_clicked                  (GtkWidget *objet, gpointer user_data);

void
on_NHretour1_clicked                  (GtkWidget *objet, gpointer user_data);

void
on_NHvalider_clicked                 (GtkWidget *objet, gpointer user_data);


/**************************************************************************/

/********************* Debut Travail Salmen *******************************/

/****************************************************************************/





void
on_shAfficher_clicked                  (GtkWidget       *shobjet,
                                        gpointer         user_data);

void
on_shok2_clicked                       (GtkWidget       *shobjet,
                                        gpointer         user_data);

void
on_shok1_clicked                       (GtkWidget       *shobjet,
                                        gpointer         user_data);


void
on_shSupprimer_clicked                 (GtkWidget       *shobjet,
                                        gpointer         user_data);

void
on_shchoisir_clicked                   (GtkWidget       *shobjet,
                                        gpointer         user_data);

void
on_shretour_clicked                    (GtkWidget       *shobjet,
                                        gpointer         user_data);

void
on_shModifier_clicked                  (GtkWidget       *shobjet,
                                        gpointer         user_data);
void
on_shAjouter_clicked                   (GtkWidget      *shobjet,
                                        gpointer         user_data);

/************************************************************************/

/**************** Debut Travail Takwa ************************************/

/**********************************************************************/


void
on_buttonsupprimertg_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonmodifertg_clicked             (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_buttonajoutertg_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonaffichagetg_clicked           (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_buttonvaliderloctg_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonvaliderprixtg_clicked         (GtkWidget      *objet_graphique,
                                        gpointer         user_data);











void
on_YKbuttonretourMenu_clicked          (GtkWidget       *objet, gpointer         user_data);

void
on_SHbuttonretourMenu_clicked          (GtkWidget       *objet, gpointer         user_data);

void
on_TGbuttonretourMenu_clicked         (GtkWidget       *objet, gpointer         user_data);

void
on_ANreservervol_clicked              (GtkWidget       *objet, gpointer         user_data);


void
on_ANreservervoiture_clicked           (GtkWidget       *objet, gpointer         user_data);


void
on_ANbuttonAfficherAcceuil_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttonR__clamation_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttonInscriptionreusite_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttuonretouracceuil_clicked      (GtkButton       *button,
                                        gpointer         user_data);
