#include <gtk/gtk.h>


void
on_ANbuttonConfirmerInscriptio_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttonSeconnecterAuthentification_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttonInscriptionAuthentification_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttonAnnulerInscription_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttonDeconnecterAcceuil_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttonConfirmerInscription_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttonSuppcompte_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANcancelbuttonSupprimerCompte_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANokbuttonSupprimerCompte_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttonModifProfil_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttonAnnulerModif_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_ANbuttonConfirmerModif_clicked      (GtkButton       *button,
                                        gpointer         user_data);
