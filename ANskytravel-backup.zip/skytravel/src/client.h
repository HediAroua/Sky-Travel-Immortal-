typedef struct
{	char user[20];
	char nom[50];
	char prenom[50];
	char email[100];
	char password[50];
	char naissance[50];
	char occupation[50];
	char civil[50];
	char enfant[20];
	char role[20];
}client;

	

int ajouter_client(char user[],char nom[],char prenom[], char email[],char naissance[] ,char password[],char occupation[],char civil[], int enfant);
void modification_profil_client (char user[], char email[],char password[],char occupation[],char civil[], int enfant);
void afficher_client ();
void supprimer_client (char user[]);

int authentification (char user[], char password[]);

