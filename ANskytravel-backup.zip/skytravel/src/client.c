#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "client.h"

int ajouter_client(char user[],char nom[],char prenom[], char email[],char naissance[] ,char password[],char occupation[],char civil[], int enfant)
{

char user1[50];
char nom1[50];
char prenom1[50];
char email1[50];
char naissance1[50];
char password1[50];
char occupation1[50];
char civil1[50];
int enfant1;

FILE *f;
int r=3; 
int x=0;
f=fopen("/home/arbi/Projects/skytravel/src/client.txt","a+");
if (f!=NULL)
	{
        while(fscanf(f,"%s %s %s %s %s %s %s %s %d %d \n",user1,nom1,prenom1,email1,password1,naissance1,occupation1,civil1,&enfant1,&r)!=EOF)
       {
        if (strcmp(user,user1)==0) 
         {
          x=1;
		return x;
          }
        }
      if (x!=1)    
         {	
	fprintf(f,"%s %s %s %s %s %s %s %s %d %d \n",user,nom,prenom,email,password,naissance,occupation,civil,enfant,r);
         }
         
         } 
	fclose(f);
      
	
}

int authentification (char user[], char password[])
{
FILE *f;
char user1[50],nom[50],prenom[50],email[50],naissance[50],occupation[50],civil[50];
char password1[50];
int role,i,enfant;
i=0;
f=fopen("/home/arbi/Projects/skytravel/src/client.txt","r");
if(f !=NULL) {
while(fscanf(f,"%s %s %s %s %s %s %s %s %d %d \n",user1,nom,prenom,email,password1,naissance,occupation,civil,&enfant,&role)!=EOF){ 
if (strcmp(user,user1)==0 && strcmp(password,password1)==0)
	{
	i=role; 
	}
}
}
fclose(f);
return i;

}


void modification_profil_client (char user[], char email[],char password[],char occupation[],char civil[], int enfant)
{
FILE *f;
FILE *f1;

char user1[50];
char nom1[50];
char prenom1[50];
char email1[50];
char naissance1[50];
char password1[50];
char occupation1[50];
char civil1[50];
int enfant1;
int r ;

f=fopen("/home/arbi/Projects/skytravel/src/client.txt","r");
f1=fopen("/home/arbi/Projects/skytravel/src/tmp.txt","w");
if(f!=NULL) 
{
	if (f1!=NULL)
	{
while(fscanf(f,"%s %s %s %s %s %s %s %s %d %d \n",user1,nom1,prenom1,email1,password1,naissance1,occupation1,civil1,&enfant1,&r)!=EOF){
	if (strcmp(user1,user)==0)
		{
	fprintf(f1,"%s %s %s %s %s %s %s %s %d %d \n",user1,nom1,prenom1,email,password,naissance1,occupation,civil,enfant,r);
		}
             else 
             {fprintf(f1,"%s %s %s %s %s %s %s %s %d %d \n",user1,nom1,prenom1,email1,password1,naissance1,occupation1,civil1,enfant1,r);
             } 

	}
}
fclose(f1);
}
fclose(f);

remove("/home/arbi/Projects/skytravel/src/client.txt");
rename("/home/arbi/Projects/skytravel/src/tmp.txt","/home/arbi/Projects/skytravel/src/client.txt");
}

void supprimer_client (char user[])
{
client a;
FILE *f;
FILE *f1;
f=fopen("src/client.txt","r");
f1=fopen("src/tmp.txt","w");
if(f!=NULL) 
 {
   if(f1!=NULL) 
    {
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s \n",a.user,a.nom,a.prenom,a.email,a.password,a.naissance,a.occupation,a.civil,a.enfant,a.role)!=EOF)
{
if(strcmp(a.user,user)!=0)
   {
fprintf(f1,"%s %s %s %s %s %s %s %s %s %s \n",a.user,a.nom,a.prenom,a.email,a.password,a.naissance,a.occupation,a.civil,a.enfant,a.role);
   }
}
}
fclose(f1);
}
fclose(f);

remove("src/client.txt");
rename("src/tmp.txt","src/client.txt");

}

