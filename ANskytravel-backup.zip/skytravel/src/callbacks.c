#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "client.h"




void
on_ANbuttonConfirmerInscription_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
char user[50], nom[50], prenom[50], email[50], password[50],naissance[50], occupation[50], civil[50];  
int enfant ;
int n=0 ; 
char test[50]="\0";
GtkWidget *output, *outputtest;
output = lookup_widget(button,"ANlabelTestUsernameAcceuil") ;
outputtest=lookup_widget(button,"ANlabelTestInscription");


GtkWidget *input1 ,*input2, *input3,*input4,*input5,*input6,*input7,*input8,*input9; 
input1=lookup_widget(button,"ANentryUsernameInscription");
input2=lookup_widget(button,"ANentryNomInscription");
input3=lookup_widget(button,"ANentryPrenomInscription");
input4=lookup_widget(button,"ANentryEmailInscription");
input5=lookup_widget(button,"ANentryPasswordInscription");
input6=lookup_widget(button,"ANentryNaissanceInscription");
input7=lookup_widget(button,"ANcomboboxOccupationInscription");
input8=lookup_widget(button,"ANcomboboxCivilInscription");
input9=lookup_widget(button,"ANspinbuttonIEnfantInscription");

strcpy(user,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(nom,gtk_entry_get_text(GTK_ENTRY(input2))); 
strcpy(prenom,gtk_entry_get_text(GTK_ENTRY(input3))); 
strcpy(email,gtk_entry_get_text(GTK_ENTRY(input4))); 
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input5))); 
strcpy(naissance,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(occupation,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input7)));
strcpy(civil,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input8)));
enfant=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input9));

if ( ((strcmp(user,test)==0) || (strcmp(nom,test)==0) || (strcmp(prenom,test)==0) || (strcmp(email,test)==0) || (strcmp(password,test)==0) || (strcmp(naissance,test)==0) || (strcmp(occupation,test)==0) || (strcmp(civil,test)==0)) )
	{
gtk_label_set_text(GTK_LABEL(outputtest),"voulez vous remplir tout les champs !");
	}
else {
n=ajouter_client(user,nom,prenom,email,naissance,password,occupation,civil,enfant);
if (n==1)
{
gtk_label_set_text(GTK_LABEL(output),"Ce nom d'utilisateur déja utilisé !");
}
else 
{

GtkWidget *window;
GtkWidget *window1;	

window = lookup_widget(button,"ANwindowInscription") ;
gtk_widget_hide (window);
window1 = create_ANwindowAcceuil();
gtk_widget_show (window1);
}
}
}


void
on_ANbuttonSeconnecterAuthentification_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *output;
GtkWidget *window;
GtkWidget *window1;

char user[50],password[50],out[100];
int role;

input1 = lookup_widget(button,"ANentryUsernameAuthentification") ;
input2 = lookup_widget(button,"ANentryPasswordAuthentification") ;
output = lookup_widget(button,"ANlabelErreurAuthentification") ;

strcpy(user,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input2)));

role = authentification(user,password);

window = lookup_widget(button,"ANwindowAuthentification") ;
if (role==3){
	gtk_widget_hide(window);
	window1 = create_ANwindowAcceuil ();
  	gtk_widget_show (window1);
/*char user1[50];nom1[50];prenom1[50];email1[50];password1[50];naissance1[50];occupation1[50];civil1[50];enfant1[50];role1[50];
FILE *f;
fopen("src/log.txt","r");
fscanf(f,"%s %s %s %s %s %s %s %s %s %s",user1,nom1,prenom1,email1,password1,naissance1,occupation1,civil1,enfant1,role1)*/
	}
else {
	strcpy(out,"Mot de passe ou nom d'utilisateur est incorrect !");
	}

gtk_label_set_text(GTK_LABEL(output),out);
}



void
on_ANbuttonInscriptionAuthentification_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
GtkWidget *window1;	

window = lookup_widget(button,"ANwindowAuthentification") ;
gtk_widget_hide (window);
window1 = create_ANwindowInscription();
gtk_widget_show (window1);
}


void
on_ANbuttonAnnulerInscription_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
GtkWidget *window1;	

window = lookup_widget(button,"ANwindowInscription") ;
gtk_widget_hide (window);
window1 = create_ANwindowAuthentification();
gtk_widget_show (window1);
}


void
on_ANbuttonDeconnecterAcceuil_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
GtkWidget *window1;	

window = lookup_widget(button,"ANwindowAcceuil") ;
gtk_widget_destroy (window);
window1 = create_ANwindowAuthentification();
gtk_widget_show (window1);
}




GtkWidget *window10;
void
on_ANbuttonSuppcompte_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;


window10=lookup_widget(button,"ANwindowAcceuil");

window = create_ANdialogSupprimerCompte ();
gtk_widget_show (window);

}


void
on_ANcancelbuttonSupprimerCompte_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;	

window = lookup_widget(button,"ANdialogSupprimerCompte");
gtk_widget_destroy (window);

}



void on_ANokbuttonSupprimerCompte_clicked   (GtkButton       *button,
                                              gpointer         user_data)
{

GtkWidget *window1;
GtkWidget *window2;
GtkWidget *input;

char user[50],password[50];

window1=lookup_widget(button,"ANdialogSupprimerCompte");
window2=create_ANwindowAuthentification() ;
gtk_widget_show(window2); 
gtk_widget_hide(window1);
gtk_widget_hide(window10);

input=lookup_widget(button,"ANentryUsernameSupprimer");
strcpy(user,gtk_entry_get_text(GTK_ENTRY(input)));

supprimer_client(user);
}


void
on_ANbuttonModifProfil_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_ANwindowModifProfil();
gtk_widget_show(window);

}


void
on_ANbuttonAnnulerModif_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=lookup_widget(button,"ANwindowModifProfil");
gtk_widget_destroy(window);
}


void
on_ANbuttonConfirmerModif_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
char user[50]; 
char email[50]; 
char password[50];
char occupation[50]; 
char civil[50]; 
int enfant ; 
GtkWidget *input0,*input1,*input2,*input3,*input4,*input5 ;

input0=lookup_widget(button,"entryuserrr");
input1=lookup_widget(button,"ANentryMailClientModif");
input2=lookup_widget(button,"ANentryPasswordClientModif");
input3=lookup_widget(button,"ANcomboboxOccupationModif");
input4=lookup_widget(button,"ANcomboboxCivilModif");
input5=lookup_widget(button,"ANspinbuttonEnfantModif");


strcpy(user,gtk_entry_get_text(GTK_ENTRY(input0))); 
strcpy(email,gtk_entry_get_text(GTK_ENTRY(input1))); 
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input2))); 

strcpy(occupation,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));
strcpy(civil,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input4)));
enfant=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));

modification_profil_client (user,email,password,occupation,civil,enfant) ;

GtkWidget *window;
window=lookup_widget(button,"ANwindowModifProfil");
gtk_widget_destroy(window);



}

