#include <gtk/gtk.h>



void on_HAbuttonAfficher_clicked    (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonAjout_clicked      (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonModifier_clicked     (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonSupprimer_clicked     (GtkWidget       *objet, gpointer         selection);

void on_HAbuttonRetour_clicked     (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonRemplir_clicked      (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonConfirmerp_clicked     (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonConfirmerd_clicked     (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonOK3_clicked     (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonConfirmerDepart3_clicked     (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonConfirmerDestination3_clicked     (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonApply3_clicked     (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonRetour3_clicked     (GtkWidget       *objet, gpointer         user_data);



void on_HAbuttonReserverVol_clicked         (GtkWidget       *objet, gpointer         user_data);


void on_HAbuttonReservervoiture_clicked     (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonAjouterPres_clicked        (GtkWidget       *objet, gpointer         user_data);


void on_HAbuttonConsulterRec_clicked        (GtkWidget       *objet, gpointer         user_data);


void on_HAbuttonDeconnexion_clicked        (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonRetourMenu1_clicked         (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonFenetreRech_clicked         (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonRechercheVol_clicked        (GtkWidget       *objet, gpointer         user_data);

void on_HAbuttonRetourRechercheVol_clicked  (GtkWidget       *objet, gpointer         user_data);


/***********************************************************************************/

void
on_HAbuttonConfirmMarque_clicked       (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonRemplirmarque_clicked       (GtkWidget       *objet, gpointer         user_data);

void
on_Habuttonajoutervoiture_clicked     (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonAffichervoiture_clicked    (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonRetourResvoiture_clicked    (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonmodifiervoiture_clicked     (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonSupprimervoiture_clicked    (GtkWidget       *objet, gpointer         selection);

void
on_HAbuttonRecherchevoiture_clicked    (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonconfirmmodmarque_clicked    (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonConfirmmodCin_clicked       (GtkWidget       *objet, gpointer         user_data);


void
on_HAbuttonApplymodvoiture_clicked     (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonretourmodvoiture_clicked    (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonrecherchevoiture_clicked   (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonRetourRecherchevoiture_clicked  (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonRetourMenu2_clicked       (GtkWidget       *objet, gpointer         user_data);

void
on_HAbuttonFenetrevoitureTakwa_clicked (GtkWidget       *objet, gpointer         user_data);

/*************************************************************************************/


/************************** Fin Travail HEDI AROUA *****************************************/

/*************************************************************************************/






/***********************************************************************************/



/******************** Debut travail Arbi Nouri **********************************/



/********************************************************************************/








