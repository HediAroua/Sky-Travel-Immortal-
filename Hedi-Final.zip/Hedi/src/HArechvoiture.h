#include <gtk/gtk.h>



void HARafficher_voiture(GtkWidget *liste);
int HARajouter_voiture(char cin[100]);
