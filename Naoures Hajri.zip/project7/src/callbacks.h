#include <gtk/gtk.h>
                              
void
on_NHajouter_clicked                   (GtkWidget *objet, gpointer user_data);

void
on_NHafficher_clicked                 (GtkWidget *objet, gpointer user_data);

void
on_NHretour_clicked                    (GtkWidget *objet, gpointer user_data);

void
on_NHsupprimer_clicked                (GtkWidget *objet, gpointer user_data);

void
on_NHmodifier_clicked                  (GtkWidget *objet, gpointer user_data);

void
on_NHretour1_clicked                  (GtkWidget *objet, gpointer user_data);

void
on_NHvalider_clicked                 (GtkWidget *objet, gpointer user_data);


