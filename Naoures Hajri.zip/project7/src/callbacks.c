#ifdef HAVE_CONFIG_H
#  include <config.h>
#include <string.h>
#endif

#include <gtk/gtk.h>
#include<gtk/gtklist.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "personne.h"
void
on_NHajouter_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *NHNom;
GtkWidget *NHPrenom;
GtkWidget *NHJour;
GtkWidget *NHMois; 
GtkWidget *NHAnnee;
GtkWidget *NHCombobox1; 
GtkWidget *NHMail;
GtkWidget *NHUsername;
GtkWidget *NHMdp;

GtkWidget *NHwindow1;

GtkWidget *NHsortie;
Personne p;
NHwindow1=lookup_widget(objet, "NHwindow1");

NHNom=lookup_widget(objet, "NHentry1");
NHPrenom=lookup_widget(objet, "NHentry2");
NHJour=lookup_widget(objet, "jour");
NHMois=lookup_widget(objet, "mois");
NHAnnee=lookup_widget(objet, "annee");
NHCombobox1=lookup_widget(objet, "NHcombobox1");
NHMail=lookup_widget(objet, "NHentry3");
NHUsername=lookup_widget(objet, "NHentry66");
NHMdp=lookup_widget(objet, "NHentry22");
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(NHNom)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(NHPrenom)));
p.dt.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(NHJour));
p.dt.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(NHMois));
p.dt.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(NHAnnee));

strcpy(p.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(NHCombobox1)));
strcpy(p.mail,gtk_entry_get_text(GTK_ENTRY(NHMail)));
strcpy(p.username,gtk_entry_get_text(GTK_ENTRY(NHUsername)));
strcpy(p.mdp,gtk_entry_get_text(GTK_ENTRY(NHMdp)));
ajouter_personne (p);
NHsortie=lookup_widget(objet,"NHlabel26");
gtk_label_set_text(GTK_LABEL(NHsortie),"Ajout réussi.");
}


void
on_NHafficher_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

	GtkWidget *NHwindow1;
	GtkWidget *NHwindow2;
	GtkWidget *NHtreeview1;

	NHwindow1=lookup_widget(objet, "NHwindow1");

	gtk_widget_destroy(NHwindow1);
	NHwindow2=lookup_widget(objet,"NHwindow2");
	NHwindow2=create_NHwindow2();

	gtk_widget_show(NHwindow2);

	NHtreeview1=lookup_widget(NHwindow2,"NHtreeview1");
	afficher_personne(NHtreeview1);

}


void
on_NHretour_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *NHwindow1, *NHwindow2;
NHwindow2=lookup_widget(objet,"NHwindow2");

gtk_widget_destroy(NHwindow2);
NHwindow1=create_NHwindow1();
gtk_widget_show(NHwindow1);
}


void
on_NHsupprimer_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
char mail[200];
GtkWidget *recherche ;

recherche=lookup_widget(objet,"NHentrymail");


strcpy(mail,gtk_entry_get_text(GTK_ENTRY(recherche)));

supprimer_personne(mail);
}


void
on_NHmodifier_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *NHwindow2 ,*NHwindow3 ;


NHwindow2=lookup_widget(objet,"NHwindow2");

gtk_widget_destroy(NHwindow2);
NHwindow3=create_NHwindow3();
gtk_widget_show(NHwindow3);
}


void
on_NHretour1_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *NHwindow3, *NHwindow2;
NHwindow3=lookup_widget(objet,"NHwindow3");

gtk_widget_destroy(NHwindow3);
NHwindow2=create_NHwindow2();
gtk_widget_show(NHwindow2);
}


void
on_NHvalider_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
char mail[30];
NewPersonne p1 ;
GtkWidget *pnom ,*pprenom ,*pdate ,*psexe ,*pmail ;
GtkWidget *NHwindow3 ;
GtkWidget *entrer;
entrer=lookup_widget(objet,"NHentrymail1");
NHwindow3=lookup_widget(objet,"NHwindow3");



pnom=lookup_widget(objet,"NHentry4");
pprenom=lookup_widget(objet,"NHentry5");
pdate=lookup_widget(objet,"NHentry6");
psexe=lookup_widget(objet,"NHcombobox2");
pmail=lookup_widget(objet,"NHentry7");
strcpy(mail,gtk_entry_get_text(GTK_ENTRY(entrer)));
strcpy(p1.nom1,gtk_entry_get_text(GTK_ENTRY(pnom)));
strcpy(p1.prenom1,gtk_entry_get_text(GTK_ENTRY(pprenom)));
strcpy(p1.naissance1,gtk_entry_get_text(GTK_ENTRY(pdate)));
strcpy(p1.sexe1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(psexe)));
strcpy(p1.mail1,gtk_entry_get_text(GTK_ENTRY(pmail)));
modifier_personne(mail,p1);
}




