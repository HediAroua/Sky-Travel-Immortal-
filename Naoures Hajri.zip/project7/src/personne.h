
#include <gtk/gtk.h>
typedef struct{
int jour;
int mois;
int annee;
}Date;
typedef struct{
char nom[20];
char prenom[30];
Date dt;
char sexe[20];
char mail[30];
char username[30];
char mdp[30];
}Personne;

typedef struct{
char nom1[20];
char prenom1[30];
char naissance1[30];
char sexe1[20];
char mail1[30];
}NewPersonne;
void ajouter_personne(Personne p);
void afficher_personne(GtkWidget *liste);
void supprimer_personne(char mail[]);
void modifier_personne(char mail[],NewPersonne p1);

