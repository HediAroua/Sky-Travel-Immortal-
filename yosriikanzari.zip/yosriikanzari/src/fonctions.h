#include <gtk/gtk.h>

typedef struct
{
char yk_type[20];
char yk_date[20];
char yk_id[20];
char yk_avis[100];

}reclamation;

void ajouter_reclamation(reclamation p);
void afficher_reclamation(GtkWidget *liste);
void supprimer_reclamation(char yk_id1[20]);
