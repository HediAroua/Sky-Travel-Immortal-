#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonctions.h"

void on_yk_rectifier_clicked                (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *yk_window1;
GtkWidget *yk_window5;

yk_window1=lookup_widget(objet,"yk_window1");

gtk_widget_hide(yk_window1);
yk_window5=lookup_widget(objet,"yk_window5");
yk_window5=create_yk_window5();
gtk_widget_show(yk_window5);
}


void
on_yk_supprimer_clicked                (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *yk_window1;
GtkWidget *yk_window3;

yk_window1=lookup_widget(objet,"yk_window1");

gtk_widget_hide(yk_window1);
yk_window3=lookup_widget(objet,"yk_window3");
yk_window3=create_yk_window3();
gtk_widget_show(yk_window3);
}


void
on_yk_ajouter_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{
reclamation p;
GtkWidget *input1,*input2,*input3;
GtkWidget *output1,*output2,*output3;
GtkWidget *yk_type;
GtkWidget *output;

char empty[]="\0";

GtkWidget *yk_window1;

yk_window1=lookup_widget(objet,"yk_window1");

output1=lookup_widget(objet,"yk_label44");
output2=lookup_widget(objet,"yk_label45");
output3=lookup_widget(objet,"yk_label46");

yk_type=lookup_widget(objet,"yk_type");
input1=lookup_widget(objet,"yk_date");
input2=lookup_widget(objet,"yk_id");
input3=lookup_widget(objet,"yk_avis");

strcpy(p.yk_date,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.yk_id,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.yk_avis,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.yk_type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(yk_type)));

if(strcmp(p.yk_date,empty)==0)
{gtk_label_set_text(GTK_LABEL(output1),"Vérifier le remplissage");}

else if(strcmp(p.yk_id,empty)==0)
{gtk_label_set_text(GTK_LABEL(output2),"Vérifier le remplissage");}

else if(strcmp(p.yk_avis,empty)==0)
{gtk_label_set_text(GTK_LABEL(output3),"Vérifier le remplissage");}

else
{
ajouter_reclamation(p);
}
output=lookup_widget(objet,"yk_label33");
gtk_label_set_text(GTK_LABEL(output),"Réclamation envoyée");

}


void on_yk_afficher_clicked                 (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *yk_window1;
GtkWidget *yk_window2;
GtkWidget *yk_treeview1;

yk_window1=lookup_widget(objet,"yk_window1");

gtk_widget_destroy(yk_window1);
yk_window2=lookup_widget(objet,"yk_window2");
yk_window2=create_yk_window2();

gtk_widget_show(yk_window2);

yk_treeview1=lookup_widget(yk_window2,"yk_treeview1");

afficher_reclamation(yk_treeview1);
}


void on_yk_retour1_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *yk_window1,*yk_window2;

yk_window2=lookup_widget(objet,"yk_window2");

gtk_widget_hide(yk_window2);
yk_window1=create_yk_window1();
gtk_widget_show(yk_window1);
}


void on_yk_confirmer_clicked                (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *yk_window3;
GtkWidget *yk_id1;
GtkWidget *output1;
GtkWidget *input1;

char empty[]="\0";
input1=lookup_widget(objet,"yk_id1");
output=lookup_widget(objet,"label43");

yk_id1=gtk_entry_get_text(GTK_ENTRY(input1));

if(strcmp(yk_id1,empty)==0)
{gtk_label_set_text(GTK_LABEL(output1),"Vérifier le remplissage");}

else
{
supprimer_reclamation(yk_id1);
}

}


void on_yk_retour3_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *yk_window1,*yk_window3;

yk_window3=lookup_widget(objet,"yk_window3");

gtk_widget_hide(yk_window3);
yk_window1=create_yk_window1();
gtk_widget_show(yk_window1);
}


void on_yk_button2_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{
reclamation p;
GtkWidget *input1,*input2,*input3;
GtkWidget *yk_type;
GtkWidget *output;

char empty[]="\0";

GtkWidget *yk_window5;

yk_window5=lookup_widget(objet,"yk_window5");


yk_type=lookup_widget(objet,"yk_typer");
input1=lookup_widget(objet,"yk_dater");
input2=lookup_widget(objet,"yk_idr");
input3=lookup_widget(objet,"yk_avisr");

strcpy(p.yk_date,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.yk_id,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.yk_avis,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.yk_type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(yk_type)));


ajouter_reclamation(p);
output=lookup_widget(objet,"yk_label43");
gtk_label_set_text(GTK_LABEL(output),"Modification envoyée");

}


void on_yk_button1_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *yk_window3;
GtkWidget *yk_idr;

GtkWidget *input1;

input1=lookup_widget(objet,"yk_idr");

yk_idr=gtk_entry_get_text(GTK_ENTRY(input1));
supprimer_reclamation(yk_idr);
}


void on_yk_button3_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *yk_window1,*yk_window5;

yk_window5=lookup_widget(objet,"yk_window5");

gtk_widget_hide(yk_window5);
yk_window1=create_yk_window1();
gtk_widget_show(yk_window1);
}

