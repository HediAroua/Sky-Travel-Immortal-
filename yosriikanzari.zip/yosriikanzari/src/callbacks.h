#include <gtk/gtk.h>

void
on_yk_rectifier_clicked                (GtkButton       *objet,
                                        gpointer         user_data);

void
on_yk_supprimer_clicked                (GtkButton       *objet,
                                        gpointer         user_data);

void
on_yk_ajouter_clicked                  (GtkButton       *objet,
                                        gpointer         user_data);

void
on_yk_afficher_clicked                 (GtkButton       *objet,
                                        gpointer         user_data);

void
on_yk_retour1_clicked                  (GtkButton       *objet,
                                        gpointer         user_data);

void
on_yk_confirmer_clicked                (GtkButton       *objet,
                                        gpointer         user_data);

void
on_yk_retour3_clicked                  (GtkButton       *objet,
                                        gpointer         user_data);

void
on_yk_button2_clicked                  (GtkButton       *objet,
                                        gpointer         user_data);

void
on_yk_button1_clicked                  (GtkButton       *objet,
                                        gpointer         user_data);

void
on_yk_button3_clicked                  (GtkButton       *objet,
                                        gpointer         user_data);
